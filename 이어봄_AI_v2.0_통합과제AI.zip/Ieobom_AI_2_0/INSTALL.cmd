@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 (
 echo Installation failed. See the message above.
 pause
 exit /b 1
)
echo Ready. Run INSTALL_MODEL.cmd for the LLM, or START.cmd for analysis.
pause
