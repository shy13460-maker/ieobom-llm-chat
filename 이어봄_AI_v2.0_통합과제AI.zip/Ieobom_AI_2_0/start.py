"""Portable launcher: reuses existing Ollama and owns only the processes it starts."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent


def get(url):
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            return json.load(response)
    except Exception:
        return None


def load_config():
    path = ROOT / 'config.json'
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {}


def ollama_executable():
    candidates = [ROOT/'runtime/ollama/ollama.exe', ROOT/'runtime/ollama.exe']
    found = shutil.which('ollama')
    if found:
        candidates.append(Path(found))
    for value in candidates:
        if value.exists():
            return str(value)
    return None


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--no-browser', action='store_true')
    args=parser.parse_args()
    config=load_config()
    env=os.environ.copy()
    model=env.get('CHAT_MODEL',config.get('model','qwen3.5:9b'))
    endpoint=env.get('OLLAMA_URL',config.get('ollama_url',''))
    children=[]
    handles=[]
    logs=ROOT/'logs'
    logs.mkdir(exist_ok=True)
    def spawn(argv,name):
        log=open(logs/(name+'.log'),'w',encoding='utf-8')
        handles.append(log)
        child=subprocess.Popen(argv,cwd=str(ROOT),env=env,stdout=log,stderr=log,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        children.append(child)
        return child
    try:
        if not endpoint:
            endpoint=next((u for u in ['http://127.0.0.1:11435','http://127.0.0.1:11434'] if get(u+'/api/tags')), '')
        if config.get('enable_local_model',False) and not endpoint and ollama_executable():
            endpoint='http://127.0.0.1:11435'
            env.update(OLLAMA_HOST='127.0.0.1:11435',OLLAMA_MODELS=str(ROOT/'models'),
                OLLAMA_NUM_PARALLEL='1',OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_NO_CLOUD='true')
            spawn([ollama_executable(),'serve'],'ollama')
            for _ in range(60):
                if get(endpoint+'/api/tags'):
                    break
                time.sleep(1)
        endpoint=endpoint or 'http://127.0.0.1:11435'
        env.update(CHAT_MODEL=model, OLLAMA_URL=endpoint, PYTHONUTF8='1')
        identity=hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]
        port=int(config.get('port',8770))
        for candidate in range(port,port+20):
            health=get('http://127.0.0.1:'+str(candidate)+'/api/health')
            if health and health.get('workspace')==identity:
                url='http://127.0.0.1:'+str(candidate)
                print('Already running: '+url,flush=True)
                if not args.no_browser:
                    webbrowser.open(url)
                return
            # Distinguish a free port from an unrelated HTTP server.
            import socket
            with socket.socket() as sock:
                if sock.connect_ex(('127.0.0.1',candidate))!=0:
                    port=candidate
                    break
        else:
            raise RuntimeError('No free local port. Change port in config.json.')
        env['CHAT_PORT']=str(port)
        server=spawn([sys.executable,'-u',str(ROOT/'app.py')],'web')
        url='http://127.0.0.1:'+str(port)
        for _ in range(45):
            health=get(url+'/api/health')
            if health and health.get('workspace')==identity:
                break
            if server.poll() is not None:
                raise RuntimeError('Server stopped. See logs/web.log.')
            time.sleep(1)
        else:
            raise RuntimeError('Server startup timed out. See logs/web.log.')
        (ROOT/'LOCAL_URL.txt').write_text(url+'\n',encoding='utf-8')
        print('Ieobom Analysis Studio: '+url,flush=True)
        print('AI: '+health.get('model',model)+' | '+('Connected' if health['ready'] else 'Configure the API key in AI settings; analysis buttons are available'),flush=True)
        print('Keep this window open. Ctrl+C stops services started by this launcher.',flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        if os.name=='nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        while server.poll() is None:
            time.sleep(2)
    except KeyboardInterrupt:
        pass
    finally:
        for child in reversed(children):
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
        for handle in handles:
            handle.close()
        if os.name=='nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


if __name__=='__main__':
    main()
