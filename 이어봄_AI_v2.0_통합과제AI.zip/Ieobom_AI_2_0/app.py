"""Local, browser-isolated analysis workspace extending the original Ieobom chat server."""
from __future__ import annotations
import base64
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
import traceback
import urllib.request
from urllib.parse import urlparse, parse_qs
from http.server import ThreadingHTTPServer
import memory_chat as chat
from analysis import service
import agent
import llm_backend as llm
import web_search

ROOT = Path(__file__).resolve().parent


def initialize():
    chat.initialize()
    with chat.connect() as con:
        con.executescript('''CREATE TABLE IF NOT EXISTS analysis_jobs(
            id TEXT PRIMARY KEY, owner TEXT, chat TEXT, status TEXT, stage TEXT,
            answer TEXT DEFAULT '', error TEXT DEFAULT '', result TEXT DEFAULT '',
            trace TEXT DEFAULT '{}', created REAL, seconds REAL DEFAULT 0);
            CREATE INDEX IF NOT EXISTS analysis_jobs_owner ON analysis_jobs(owner,created);''')
        con.execute("UPDATE analysis_jobs SET status='error',error='프로그램 재시작으로 작업이 중단됐습니다. 다시 실행해 주세요.' WHERE status='running'")


def update(jid, **fields):
    with chat.connect() as con:
        con.execute('UPDATE analysis_jobs SET ' + ','.join(k+'=?' for k in fields) + ' WHERE id=?', [*fields.values(), jid])


def job(owner, jid, data):
    started = time.monotonic()
    cid = data.get('chat')
    result, trace, warning = None, {}, ''
    context_token=llm.OWNER.set(owner)
    try:
        if data.get('action')=='test_connection':
            update(jid,stage='선택한 모델에 연결 시험 중')
            answer=llm.complete([dict(role='user',content='연결 시험입니다. 다른 설명 없이 연결 성공이라고만 답하세요.')],limit=100,effort='low')
            update(jid,status='done',stage='연결 시험 완료',answer=answer,seconds=time.monotonic()-started)
            return
        cfg, did, rid = data.get('config') or {}, data.get('dataset'), data.get('result')
        action, text = data.get('action'), data.get('text', '')
        if action == 'assistant' and data.get('mode') == 'general' and not agent.wants_analysis(text):
            action = 'chat'
            inputs = {}
            trace = dict(planner='일반 대화 · 분석 도구 호출 없음', action='chat', mode='general')
            update(jid, stage='답변을 준비하고 있습니다')
        elif action == 'assistant':
            update(jid, stage='LLM이 요청을 해석하고 있습니다')
            did,cfg = agent.prepare_analysis(owner,text,did,cfg)
            context = dict(settings=cfg, selected_result=rid)
            if did:
                info = service.describe(owner, did)
                context['dataset'] = {k: info[k] for k in ('name', 'columns', 'numeric', 'rows')}
            if rid:
                r = service.load_result(owner, rid)
                context['selected_result'] = dict(id=rid, kind=r['kind'], config=r['config'])
            p = agent.plan(text, context)
            action = p['action']
            cfg = dict(cfg, **p['config'])
            inputs = p['inputs']
            trace = dict(planner=llm.model_name(), action=action, reason=str(p.get('reason', ''))[:400], config=cfg, inputs=inputs)
        else:
            inputs = data.get('inputs') or {}
            trace = dict(planner='사용자가 설정 버튼으로 직접 실행', action=action, config=cfg, inputs=inputs)
        update(jid, stage='답변을 준비하고 있습니다' if action == 'chat' else '도구를 실행하고 있습니다', trace=json.dumps(trace, ensure_ascii=False))
        progress = lambda text: update(jid, stage=text)
        result = agent.execute(owner, did, rid, action, cfg, inputs, progress)
        trace['completed'] = True
        if data.get('action')=='assistant':
            trace['answer_model']=llm.model_name()
        trace['result_id'] = result.get('id') if result else None
        if result and result.get('id') and action not in ('explain',):
            result['execution'] = dict(trace, request=text)
            service.write_json(service.owned_dir(owner)/(result['id']+'.result.json'), result)
        if data.get('action') == 'assistant':
            if not result and data.get('web_search') is True and web_search.needs_search(text):
                update(jid, stage='웹에서 공개 자료를 검색하고 있습니다')
                with chat.connect() as con:
                    context = [dict(r) for r in con.execute('SELECT role,content FROM messages WHERE chat=? AND role=? ORDER BY id DESC LIMIT 2',(cid,'user'))][::-1]
                query = web_search.query_for(text, context)
                try:
                    trace['web'] = dict(query=query, provider='DuckDuckGo', sources=web_search.search(query))
                except Exception:
                    trace['web'] = dict(query=query, error='공개 검색 결과를 가져오지 못했습니다. 검색 서비스 제한이나 인터넷 연결을 확인해 주세요.')
            update(jid, stage='LLM이 실제 결과를 설명하고 있습니다' if result else '이어봄이 답변을 작성하고 있습니다')
            try:
                interpretation = agent.answer(owner, cid, text, result, trace)
                answer = agent.factual_answer(result)+'\n\n[LLM 결과 해석]\n'+interpretation if result else interpretation
            except Exception as exc:
                if not result:
                    if isinstance(exc,ValueError):
                        raise
                    raise ValueError('LLM 답변을 생성하지 못했습니다. 연결 상태를 확인해 주세요.')
                answer = agent.factual_answer(result)
                warning = '\n\nLLM 설명 생성에는 실패했지만 위 계산은 완료됐습니다.' + ('\n'+str(exc) if isinstance(exc,ValueError) else '')
        else:
            answer = agent.factual_answer(result)
        answer += warning
        if cid:
            with chat.connect() as con:
                now = time.time()
                con.executemany('INSERT INTO messages(chat,role,content,created) VALUES(?,?,?,?)',
                    [(cid, 'user', text, now), (cid, 'assistant', answer, now)])
                con.execute('''INSERT INTO memories(owner,source_message,content,created)
                    SELECT ?,id,content,created FROM messages WHERE chat=? AND role='user' ORDER BY id DESC LIMIT 1''', (owner, cid))
                con.execute("UPDATE chats SET updated=?,title=CASE WHEN title='새 대화' THEN ? ELSE title END WHERE id=?", (now, text[:35], cid))
        update(jid, status='done', stage='완료', answer=answer,
               result=json.dumps(service.clean_json(result), ensure_ascii=False, allow_nan=False) if result else '',
               trace=json.dumps(trace, ensure_ascii=False), seconds=time.monotonic()-started)
    except Exception as exc:
        traceback.print_exc()
        error = str(exc)[:500] if isinstance(exc, ValueError) else '작업에 실패했습니다. 설정과 실행 로그를 확인해 주세요.'
        update(jid, status='error', error=error, seconds=time.monotonic()-started)
    finally:
        llm.OWNER.reset(context_token)
        chat.GATE.release()


class Handler(chat.Handler):
    def do_GET(self):
        path = urlparse(self.path).path
        owner = self.identity()
        try:
            if path=='/api/ai-settings':
                return self.reply(llm.public_settings(owner))
            if path == '/api/health':
                settings=llm.public_settings(owner)
                if settings['provider']=='gemini':
                    return self.reply(dict(model=settings['model'],ready=settings['verified'],configured=settings['key_saved'],
                        provider='gemini',busy=chat.GATE.locked(),endpoint='Google Gemini API',
                        message='연결 확인 완료' if settings['verified'] else 'API 설정됨 · 연결 시험 필요',
                        app='ieobom-analysis',workspace=hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]))
                models, error = [], ''
                try:
                    with urllib.request.urlopen(chat.OLLAMA+'/api/tags', timeout=2) as response:
                        models = [r['name'] for r in json.load(response).get('models', [])]
                except Exception:
                    error = 'LLM 연결 전 · 분석 버튼은 사용 가능'
                return self.reply(dict(model=chat.MODEL, ready=chat.MODEL in models, models=models,
                    busy=chat.GATE.locked(), endpoint=chat.OLLAMA, message=error,provider='local',
                    app='ieobom-analysis', workspace=hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]))
            if path == '/api/workspace':
                datasets = []
                for p in service.owned_dir(owner).glob('*.dataset.json'):
                    obj = json.loads(p.read_text(encoding='utf-8'))
                    datasets.append(dict(id=p.name.split('.')[0], name=obj['name'], created=obj['created']))
                with chat.connect() as con:
                    pending = [dict(r) for r in con.execute("SELECT id,chat,stage FROM analysis_jobs WHERE owner=? AND status='running'", (owner,))]
                return self.reply(dict(datasets=sorted(datasets, key=lambda d: d['created'], reverse=True), results=service.list_results(owner), pending=pending))
            if path.startswith('/api/data/'):
                return self.reply(service.describe(owner, path.rsplit('/', 1)[-1]))
            if path.startswith('/api/result/'):
                return self.reply(service.load_result(owner, path.rsplit('/', 1)[-1]))
            if path.startswith('/api/task/'):
                with chat.connect() as con:
                    row = con.execute('SELECT id,chat,status,stage,answer,error,result,trace,seconds FROM analysis_jobs WHERE id=? AND owner=?', (path.rsplit('/', 1)[-1], owner)).fetchone()
                if not row:
                    return self.reply(dict(error='작업을 찾을 수 없습니다.'), 404)
                obj = dict(row)
                obj['result'] = json.loads(obj['result']) if obj['result'] else None
                obj['trace'] = json.loads(obj['trace'])
                return self.reply(obj)
            if path.startswith('/download/'):
                name = path.rsplit('/', 1)[-1]
                rid, ext = name.rsplit('.', 1)
                result = service.load_result(owner, rid)
                if ext == 'xlsx':
                    return self.reply(service.export(owner, rid), mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                if ext == 'json':
                    return self.reply(json.dumps(result, ensure_ascii=False, indent=2).encode(), mime='application/json; charset=utf-8')
                raise ValueError('지원하지 않는 다운로드입니다.')
        except (ValueError, KeyError) as exc:
            return self.reply(dict(error=str(exc)), 400)
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path not in ('/api/upload', '/api/sample', '/api/run', '/api/delete-chat','/api/ai-settings','/api/ai-test'):
            return super().do_POST()
        owner = self.identity()
        origin = self.headers.get('Origin')
        if origin and urlparse(origin).netloc != self.headers.get('Host'):
            return self.reply(dict(error='허용되지 않은 요청입니다.'), 403)
        if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            return self.reply(dict(error='JSON 요청이 필요합니다.'), 415)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 0 or size > (12*1024*1024 if path == '/api/upload' else 40000):
                return self.reply(dict(error='요청이 너무 큽니다.'), 413)
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ValueError('잘못된 요청입니다.')
            if path=='/api/ai-settings':
                if not chat.GATE.acquire(blocking=False):
                    return self.reply(dict(error='진행 중인 응답이 끝난 후 연결 설정을 바꿔 주세요.'),409)
                try:
                    return self.reply(llm.save_settings(owner,data))
                finally:
                    chat.GATE.release()
            if path=='/api/ai-test':
                if data.get('provider') != llm.public_settings(owner)['provider']:
                    raise ValueError('선택한 실행 방식을 먼저 저장한 후 연결 시험을 눌러 주세요.')
                if not chat.GATE.acquire(blocking=False):
                    return self.reply(dict(error='다른 작업이 진행 중입니다.'),429)
                jid=secrets.token_hex(16)
                try:
                    with chat.connect() as con:
                        con.execute('INSERT INTO analysis_jobs(id,owner,chat,status,stage,created) VALUES(?,?,?,?,?,?)',
                            (jid,owner,'','running','연결 시험 준비',time.time()))
                    threading.Thread(target=job,args=(owner,jid,dict(action='test_connection')),daemon=True).start()
                except Exception:
                    chat.GATE.release()
                    raise
                return self.reply(dict(job=jid),202)
            if path == '/api/upload':
                return self.reply(service.upload(owner, data['name'], base64.b64decode(data['content'], validate=True), data.get('header', 1), data.get('sheet')), 201)
            if path == '/api/sample':
                return self.reply(service.ann_sample(owner) if data.get('kind') == 'ann' else service.sample(owner), 201)
            if path == '/api/delete-chat':
                # The inherited method cannot reread an already consumed request body.
                cid = data.get('chat')
                if not chat.GATE.acquire(blocking=False):
                    return self.reply(dict(error='진행 중인 작업이 끝난 후 삭제해 주세요.'), 409)
                try:
                    with chat.connect() as con:
                        if not con.execute('SELECT id FROM chats WHERE id=? AND owner=?', (cid, owner)).fetchone():
                            return self.reply(dict(error='채팅을 찾을 수 없습니다.'), 404)
                        for table in ('messages', 'jobs', 'analysis_jobs'):
                            con.execute('DELETE FROM '+table+' WHERE chat=?', (cid,))
                        con.execute('DELETE FROM chats WHERE id=?', (cid,))
                    return self.reply(dict(deleted=True))
                finally:
                    chat.GATE.release()
            if data.get('action') not in agent.ACTIONS + ['assistant']:
                raise ValueError('지원하지 않는 요청입니다.')
            if data.get('mode', 'analysis') not in ('general', 'analysis'):
                raise ValueError('대화 모드를 확인해 주세요.')
            cid = data.get('chat')
            if not isinstance(cid, str) or not isinstance(data.get('text', ''), str) or len(data.get('text', '').encode()) > 6000:
                raise ValueError('채팅과 질문을 확인해 주세요. 질문은 6,000바이트 이내로 입력하세요.')
            if not isinstance(data.get('config', {}), dict):
                raise ValueError('분석 설정을 확인해 주세요.')
            with chat.connect() as con:
                if not con.execute('SELECT id FROM chats WHERE id=? AND owner=?', (cid, owner)).fetchone():
                    raise ValueError('본인의 채팅을 선택해 주세요.')
            if data.get('dataset'):
                service.dataset(owner, data['dataset'])
            if data.get('result'):
                service.load_result(owner, data['result'])
            if not chat.GATE.acquire(blocking=False):
                return self.reply(dict(error='다른 작업이 진행 중입니다. 완료 후 실행해 주세요.'), 429)
            jid = secrets.token_hex(16)
            try:
                with chat.connect() as con:
                    con.execute('INSERT INTO analysis_jobs(id,owner,chat,status,stage,created) VALUES(?,?,?,?,?,?)',
                        (jid, owner, cid, 'running', '작업 준비 중', time.time()))
                threading.Thread(target=job, args=(owner, jid, data), daemon=True).start()
            except Exception:
                chat.GATE.release()
                raise
            return self.reply(dict(job=jid), 202)
        except (ValueError, KeyError, TypeError) as exc:
            return self.reply(dict(error=str(exc)), 400)
        except Exception:
            traceback.print_exc()
            return self.reply(dict(error='파일을 읽거나 작업을 준비하지 못했습니다. 파일 형식을 확인해 주세요.'), 400)


if __name__ == '__main__':
    initialize()
    port = int(os.environ.get('CHAT_PORT', '8770'))
    print(f'이어봄 분석실: http://127.0.0.1:{port}', flush=True)
    ThreadingHTTPServer(('127.0.0.1', port), Handler).serve_forever()
