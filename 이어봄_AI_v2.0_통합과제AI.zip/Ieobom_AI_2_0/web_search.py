"""Public DuckDuckGo HTML search, without API keys or a paid search service.

Only explicit user question text is used as a query; never saved memories, files,
credentials, or generated instructions. Results are untrusted snippets, not page reads.
"""
from html import unescape
from html.parser import HTMLParser
import re
import os
import subprocess
import shutil
from pathlib import Path
import urllib.request
from urllib.parse import quote, urlsplit, parse_qs


def needs_search(text):
    return any(word in text.lower() for word in ('검색','찾아','최신','최근','오늘','뉴스','실시간','등급컷','발표','올해','내년','가격','환율','날씨','2026','2027'))


def query_for(text, messages=()):
    text = ' '.join(text.split())
    # Follow-up requests can omit the year/topic; use only the last user question.
    if not re.search(r'20\d{2}|수능|날씨|환율', text):
        for msg in reversed(messages):
            if msg.get('role') == 'user' and needs_search(msg.get('content','')):
                text = msg['content'][:160] + ' ' + text
                break
    return text[:300]


def public_url(value):
    value = unescape(value)
    if value.startswith('//'):
        value = 'https:' + value
    parsed = urlsplit(value)
    if parsed.hostname in ('duckduckgo.com','html.duckduckgo.com'):
        value = parse_qs(parsed.query).get('uddg',[''])[0]
        parsed = urlsplit(value)
    if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password:
        return ''
    return value


class Results(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self.row = None
        self.capture = None
        self.depth = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = attrs.get('class','').split()
        if tag == 'a' and 'result__a' in classes:
            url = public_url(attrs.get('href',''))
            self.row = dict(title='',url=url,snippet='') if url else None
            if self.row:
                self.rows.append(self.row)
            self.capture, self.depth = 'title', 1
        elif 'result__snippet' in classes and self.row:
            self.capture, self.depth = 'snippet', 1
        elif self.capture and tag not in ('br','img','meta','input','hr','link'):
            self.depth += 1

    def handle_endtag(self, tag):
        if self.capture:
            self.depth -= 1
            if self.depth <= 0:
                self.capture = None

    def handle_data(self, data):
        if self.capture and self.row:
            self.row[self.capture] += data


def _fetch(url):
    if os.name == 'nt':
        # Use the Windows HTTP client verified on the target desktop. The query
        # is stdin data, never interpolated into executable PowerShell source.
        script = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $target=[Console]::In.ReadToEnd(); $r=Invoke-WebRequest -Uri $target -UseBasicParsing -TimeoutSec 20; [Console]::Write($r.Content)"
        bundled = Path(__file__).resolve().parent/'runtime/powershell/pwsh.exe'
        executable = str(bundled) if bundled.exists() else shutil.which('pwsh')
        if not executable:
            raise ValueError('웹 검색 실행 환경을 준비하려면 INSTALL.cmd를 다시 실행해 주세요.')
        completed = subprocess.run([executable,'-NoProfile','-NonInteractive','-Command',script],input=url.encode('ascii'),capture_output=True,timeout=30,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        return completed.stdout
    with urllib.request.urlopen(urllib.request.Request(url), timeout=20) as response:
        return response.read(1_000_001)


def search(query):
    url = 'https://html.duckduckgo.com/html/?q=' + quote(query, safe='')
    raw = _fetch(url)
    if len(raw) > 1_000_000:
        raise ValueError('검색 결과의 크기가 너무 큽니다.')
    parser = Results()
    parser.feed(raw.decode('utf-8', errors='replace'))
    rows, seen = [], set()
    for row in parser.rows:
        if row['url'] in seen or not row['title'].strip():
            continue
        seen.add(row['url'])
        rows.append(dict(title=' '.join(row['title'].split())[:200],url=row['url'],snippet=' '.join(row['snippet'].split())[:900]))
        if len(rows) == 5:
            break
    if not rows:
        raise ValueError('검색 결과를 읽지 못했습니다. 검색 서비스 제한 또는 검색어를 확인해 주세요.')
    return rows


def sources_text(rows):
    return '\n\n검색 출처 (검색 결과의 제목·요약 기준)\n' + '\n'.join(f'[{i}] {row["title"]}\n{row["url"]}' for i,row in enumerate(rows,1))
