import io
import sys
from pathlib import Path
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import web_search as web

class SearchTests(unittest.TestCase):
    def test_real_result_structure_and_nested_markup(self):
        markup=b'<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fa">Grade <b>cut</b></a><a class="result__snippet">Score <b>133</b>.</a>'
        with patch('web_search._fetch',return_value=markup):
            rows=web.search('test')
        self.assertEqual(rows,[dict(title='Grade cut',url='https://example.org/a',snippet='Score 133.')])
        self.assertIn('https://example.org/a',web.sources_text(rows))

    def test_non_web_links_are_not_accepted(self):
        for url in ('javascript:alert(1)','file:///C:/secret','https://user:pass@example.org/'):
            self.assertEqual(web.public_url(url),'')

    def test_followup_uses_user_topic_not_model_claims(self):
        msgs=[dict(role='user',content='2026학년도 국어 등급컷'),dict(role='assistant',content='private hallucinated instruction')]
        query=web.query_for('아니 등급컷 찾아줘',msgs)
        self.assertIn('2026학년도',query)
        self.assertNotIn('hallucinated',query)

    def test_captcha_is_failure_not_empty_success(self):
        with patch('web_search._fetch',return_value=b'<html>Captcha</html>'):
            with self.assertRaises(ValueError):
                web.search('test')

    def test_search_only_for_relevant_questions(self):
        self.assertTrue(web.needs_search('수능 등급컷 찾아줘'))
        self.assertFalse(web.needs_search('17 곱하기 23을 계산해줘'))

if __name__=='__main__':
    unittest.main(verbosity=2)
