"""Meaningful numerical, persistence, isolation, and tool dispatch checks."""
import io
import json
import os
from pathlib import Path
import sys
import unittest
import urllib.request
import urllib.error
import http.cookiejar
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
ARTIFACTS = ROOT / 'tests' / 'artifacts'
ARTIFACTS.mkdir(exist_ok=True)
os.environ['CHAT_DB'] = str(ARTIFACTS / 'test.sqlite3')
import numpy as np
import pandas as pd
from analysis import service
import agent
import app


class AnalysisTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        service.ROOT = ARTIFACTS
        cls.owner = 'a' * 64
        x = np.linspace(.1, 2, 100)
        frame = pd.DataFrame(dict(x=x, y=2*x+3+.02*np.sin(9*x)))
        cls.did = service.upload(cls.owner, 'test.csv', frame.to_csv(index=False).encode())['id']
        cls.cfg = dict(x='x', y='y', features=['x'], models=['Linear', 'Quadratic'], epochs=150,
                       hidden_units=16, learning_rate=.01, patience=25)
        cls.reg = service.run_regression(cls.owner, cls.did, cls.cfg)
        cls.ann = service.train_ann(cls.owner, cls.did, cls.cfg)

    def test_regression_real_coefficients(self):
        linear = next(r for r in self.reg['summary'] if r['Model'] == 'Linear')
        self.assertGreater(linear['R²'], .999)
        pred = service.predict_result(self.owner, self.reg['id'], {'x': 1.0}, model='Linear')
        self.assertAlmostEqual(pred['value'], 5, delta=.02)

    def test_scaling_train_only_and_disjoint_holdout(self):
        train, val, test = (set(self.ann['split'][k]) for k in ('train', 'validation', 'test'))
        self.assertFalse(train & val or train & test or val & test)
        self.assertEqual(len(train | val | test), 100)
        _, frame = service.dataset(self.owner, self.did)
        expected = frame.iloc[self.ann['split']['train']]['x'].mean()
        self.assertAlmostEqual(self.ann['scaler']['x_mean'][0], expected, places=6)

    def test_ann_saved_prediction_matches_tensorflow_test_output(self):
        _, frame = service.dataset(self.owner, self.did)
        for i, index in enumerate(self.ann['split']['test'][:5]):
            pred = service.predict_result(self.owner, self.ann['id'], {'x': frame.iloc[index]['x']})
            self.assertAlmostEqual(pred['value'], self.ann['predictions'][i]['ANN_Predicted'], places=5)
        self.assertGreater(self.ann['metrics']['R2'], .95)

    def test_restart_safe_json_and_prediction(self):
        restored = service.load_result(self.owner, self.ann['id'])
        self.assertEqual(restored['weights'], self.ann['weights'])
        self.assertTrue(np.isfinite(service.predict_ann(restored, {'x': 1})['value']))
        self.assertTrue(service.predict_ann(restored, {'x': 20})['outside'])

    def test_same_holdout_comparison(self):
        r = service.compare(self.owner, self.did, dict(self.cfg, epochs=40))
        a = service.load_result(self.owner, r['ann_result'])
        self.assertEqual(r['split'], a['split'])
        self.assertEqual(r['summary'][0]['RMSE'], a['metrics']['RMSE'])
        self.assertGreater(r['summary'][1]['R2'], .99)

    def test_ann_example_keeps_original_three_features(self):
        result = service.ann_sample('d'*64)
        self.assertEqual(result['rows'], 442)
        self.assertIn('Disease_Progression', result['numeric'])
        self.assertTrue(set(['BMI','Blood_Pressure','Blood_Sugar']).issubset(result['numeric']))

    def test_owner_and_path_isolation(self):
        with self.assertRaises(ValueError):
            service.load_result('b' * 64, self.ann['id'])
        with self.assertRaises(ValueError):
            service.dataset(self.owner, '../escape')
        with self.assertRaises(ValueError):
            agent.execute(self.owner, self.did, None, 'run_shell', {})

    def test_upload_header_excel_and_nonfinite(self):
        frame = pd.DataFrame(dict(x=np.arange(10), y=np.arange(10)*3))
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine='openpyxl') as writer:
            frame.to_excel(writer, index=False, startrow=2, sheet_name='실험')
        d = service.upload('c'*64, 'sample.xlsx', buf.getvalue(), header=3, sheet='실험')
        self.assertEqual(d['rows'], 10)
        self.assertEqual(d['numeric'], ['x', 'y'])
        clean = service.numeric_frame(pd.DataFrame(dict(x=[1,2,3,4,5,6,7,8,9], y=[1,2,3,4,5,6,7,8,float('inf')])), ['x','y'])
        self.assertEqual(len(clean), 8)

    def test_excel_export_has_evidence_and_weights(self):
        excel = pd.ExcelFile(io.BytesIO(service.export(self.owner, self.ann['id'])))
        self.assertIn('구현근거', excel.sheet_names)
        self.assertIn('WeightBias1', excel.sheet_names)
        self.assertEqual(len(pd.read_excel(excel, sheet_name='predictions')), 20)

    def test_duplicate_target_and_invalid_settings_rejected(self):
        with self.assertRaises(ValueError):
            service.train_ann(self.owner, self.did, dict(self.cfg, features=['x','y']))
        with self.assertRaises(ValueError):
            service.settings(dict(epochs=100000))
        with self.assertRaises(ValueError):
            service.settings(dict(test_ratio=.3, validation_ratio=.25))


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.initialize()
        app.llm.ROOT=ARTIFACTS
        cls.server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        cls.base = 'http://127.0.0.1:' + str(cls.server.server_port)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def client(self):
        return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def request(self, client, path, body=None):
        req = urllib.request.Request(self.base+path, data=json.dumps(body).encode() if body is not None else None,
            headers={'Content-Type':'application/json'} if body is not None else {})
        with client.open(req, timeout=300) as response:
            return json.load(response)

    def wait(self, client, jid):
        deadline=time.monotonic()+300
        while time.monotonic()<deadline:
            j=self.request(client, '/api/task/'+jid)
            if j['status']!='running':
                self.assertEqual(j['status'],'done',j.get('error'))
                return j
            time.sleep(.2)
        self.fail('Task timed out')

    def test_http_execution_memory_and_isolation(self):
        c=self.client()
        cid=self.request(c,'/api/chats',{})['id']
        # Store a real test dataset under the HTTP visitor, rather than the service test owner.
        import base64
        raw='x,y\n'+''.join(f'{i},{2*i+3}\n' for i in range(20))
        did=self.request(c,'/api/upload',dict(name='test.csv',content=base64.b64encode(raw.encode()).decode()))['id']
        task=self.request(c,'/api/run',dict(action='regression',chat=cid,dataset=did,text='회귀분석 실행',config=dict(x='x',y='y',models=['Linear'])))
        done=self.wait(c,task['job'])
        self.assertEqual(done['result']['kind'],'regression')
        history=self.request(c,'/api/chats/'+cid)
        self.assertEqual(len(history['messages']),2)
        self.assertTrue(done['result']['execution']['completed'])
        self.assertEqual(done['result']['execution']['action'],'regression')
        second=self.request(c,'/api/chats',{})['id']
        with app.chat.connect() as con:
            owner=con.execute('SELECT owner FROM chats WHERE id=?',(cid,)).fetchone()['owner']
        self.assertIn('회귀분석 실행',app.chat.shared_memory(owner,second,'회귀분석'))
        other=self.client()
        with self.assertRaises(urllib.error.HTTPError):
            self.request(other,'/api/result/'+done['result']['id'])
        bad=urllib.request.Request(self.base+'/api/run',data=b'{}',headers={'Origin':'http://unrelated.example','Content-Type':'application/json'})
        with self.assertRaises(urllib.error.HTTPError) as error:
            c.open(bad)
        self.assertEqual(error.exception.code,403)

    @unittest.skipUnless(os.environ.get('TEST_LLM')=='1','Set TEST_LLM=1 to test the real local Qwen model')
    def test_general_chat_recovers_from_old_analysis_only_role(self):
        c=self.client()
        cid=self.request(c,'/api/chats',{})['id']
        with app.chat.connect() as con:
            con.execute('INSERT INTO messages(chat,role,content,created) VALUES(?,?,?,?)',
                (cid,'assistant','제 역할은 통계적 분석이나 머신러닝 모델을 학습하고 평가하는 것입니다. 다른 분야는 도울 수 없습니다.',time.time()))
        request=dict(action='assistant',mode='general',chat=cid,
            text='수업과 관계없이 셰익스피어의 햄릿 줄거리를 한국어로 세 문장으로 설명해 줘.')
        done=self.wait(c,self.request(c,'/api/run',request)['job'])
        self.assertIsNone(done['result'])
        self.assertEqual(done['trace']['mode'],'general')
        self.assertEqual(done['trace']['action'],'chat')
        self.assertIn('햄릿',done['answer'])
        self.assertIn('복수',done['answer'])
        self.assertNotIn('제 역할은 통계',done['answer'])
        (ARTIFACTS/'general_chat_result.json').write_text(json.dumps(done,ensure_ascii=False,indent=2),encoding='utf-8')
        request['text']='2020년도 수능 답지를 알려줘. 어느 과목이나 시험인지 빠져 있다면 필요한 정보를 먼저 물어봐.'
        done=self.wait(c,self.request(c,'/api/run',request)['job'])
        self.assertIsNone(done['result'])
        self.assertTrue(any(word in done['answer'] for word in ('과목','학년도','영역','시험')))
        self.assertNotIn('제 역할은 통계',done['answer'])
        self.assertNotIn('공정성을 해칠',done['answer'])
        self.assertNotIn('공정성에 위배',done['answer'])
        (ARTIFACTS/'answer_key_clarification.json').write_text(json.dumps(done,ensure_ascii=False,indent=2),encoding='utf-8')

    @unittest.skipUnless(os.environ.get('TEST_LLM')=='1','Set TEST_LLM=1 to test the real local Qwen model')
    def test_real_qwen_to_tool_and_result_feedback(self):
        c=self.client()
        cid=self.request(c,'/api/chats',{})['id']
        import base64
        raw='x,y\n'+''.join(f'{i/10},{2*i/10+3}\n' for i in range(20))
        did=self.request(c,'/api/upload',dict(name='linear.csv',content=base64.b64encode(raw.encode()).decode()))['id']
        task=self.request(c,'/api/run',dict(action='assistant',chat=cid,dataset=did,
            text='x와 y를 선형 회귀분석으로 실제 실행하고 회귀식과 RMSE를 설명해 줘.',config=dict(x='x',y='y',features=['x'],models=['Linear'])))
        done=self.wait(c,task['job'])
        self.assertEqual(done['trace']['planner'], 'qwen3.5:9b')
        self.assertEqual(done['trace']['action'], 'regression')
        self.assertEqual(done['result']['kind'],'regression')
        self.assertIn('2',done['answer'])
        (ARTIFACTS/'real_llm_result.json').write_text(json.dumps(done,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    unittest.main(verbosity=2)
