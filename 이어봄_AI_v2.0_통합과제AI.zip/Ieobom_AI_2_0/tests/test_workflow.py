"""Exercise the real HTTP -> planner -> numerical tool -> saved result workflow."""
import http.cookiejar
import json
from pathlib import Path
import shutil
import sys
import threading
import time
import unittest
from unittest.mock import patch
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app
import agent
from analysis import service


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_service=service.ROOT
        cls.old_db=app.chat.DB
        cls.artifacts=ROOT/'tests/workflow_artifacts'
        (cls.artifacts/'examples').mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/'examples/yacht.csv',cls.artifacts/'examples/yacht.csv')
        service.ROOT=cls.artifacts
        app.chat.DB=cls.artifacts/'chat.sqlite3'
        app.initialize()
        cls.server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        cls.base='http://127.0.0.1:'+str(cls.server.server_port)
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        service.ROOT=cls.old_service
        app.chat.DB=cls.old_db

    def request(self,client,path,data=None):
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
        with client.open(req,timeout=30) as response:
            return json.load(response)

    def run_assignment(self,text,action,config):
        client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        cid=self.request(client,'/api/chats',{})['id']
        def fake_complete(messages,limit=900,schema=None,effort=None):
            return json.dumps(dict(action=action,reason='검증용 계획',config=config,inputs={})) if schema else '실제 계산 결과를 확인했습니다.'
        with patch('llm_backend.complete',side_effect=fake_complete):
            task=self.request(client,'/api/run',dict(action='assistant',mode='general',text=text,chat=cid,config={}))
            deadline=time.monotonic()+180
            while time.monotonic()<deadline:
                result=self.request(client,'/api/task/'+task['job'])
                if result['status']!='running':
                    break
                time.sleep(.2)
        self.assertEqual(result['status'],'done',result.get('error'))
        self.assertEqual(result['result']['kind'],action)
        self.assertTrue(result['result']['execution']['completed'])
        self.assertEqual(result['trace']['planner'],'gemini-3.5-flash-lite')
        saved=self.request(client,'/api/chats/'+cid)
        self.assertEqual(len(saved['messages']),2)
        exported=client.open(self.base+'/download/'+result['result']['id']+'.xlsx').read()
        self.assertTrue(exported.startswith(b'PK'))
        (self.artifacts/(action+'.json')).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
        return result

    def test_regression_from_general_chat_without_manual_dataset(self):
        result=self.run_assignment('선박 예제로 선형 회귀분석을 실행해 줘','regression',dict(models=['Linear']))
        self.assertEqual(result['result']['config']['x'],'Froude_Number')

    def test_ann_from_general_chat_without_manual_dataset(self):
        result=self.run_assignment('ANN 예제로 은닉 뉴런 3개, 최대 15에포크 학습해 줘','ann',dict(hidden_units=3,epochs=15))
        self.assertEqual(result['result']['config']['hidden_units'],3)
        self.assertEqual(result['result']['parameters_count'],16)

    def test_concept_questions_do_not_start_training(self):
        self.assertFalse(agent.wants_analysis('ANN의 역전파가 무엇이야?'))
        self.assertTrue(agent.wants_analysis('ANN을 100에포크 학습해 줘'))

    def test_error_bars_keep_row_alignment_and_do_not_weight_fit(self):
        owner='d'*64
        raw='x,y,error\n'+''.join(f'{i},{"bad" if i==4 else 2*i+3},{-.2 if i==5 else .2}\n' for i in range(1,13))
        did=service.upload(owner,'errorbars.csv',raw.encode())['id']
        result=service.run_regression(owner,did,dict(x='x',y='y',models=['Linear'],y_error='error'))
        curve=result['curves'][0]
        self.assertEqual(len(curve['error_y']),len(curve['actual_x']))
        self.assertNotIn(4,curve['actual_x'])
        self.assertIsNone(curve['error_y'][curve['actual_x'].index(5)])
        self.assertAlmostEqual(result['summary'][0]['R²'],1.0)
        import io
        import pandas as pd
        self.assertIn('입력데이터',pd.ExcelFile(io.BytesIO(service.export(owner,result['id']))).sheet_names)

if __name__=='__main__':
    unittest.main(verbosity=2)
