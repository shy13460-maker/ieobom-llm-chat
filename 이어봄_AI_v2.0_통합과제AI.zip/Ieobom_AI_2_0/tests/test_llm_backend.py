import io
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import urllib.error

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import llm_backend as llm


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.old_root=llm.ROOT
        llm.ROOT=ROOT/'tests/backend_artifacts'
        import secrets
        self.owner=secrets.token_hex(32)
        self.token=llm.OWNER.set(self.owner)
        self.secret='test-only-not-a-real-key-123456789'

    def tearDown(self):
        llm.OWNER.reset(self.token)
        llm.ROOT=self.old_root

    def save(self,**changes):
        data=dict(provider='gemini',api_key=self.secret,free_project_confirmed=True,thinking='high',daily_limit=20)
        data.update(changes)
        return llm.save_settings(self.owner,data)

    def test_secret_encryption_and_visitor_isolation(self):
        public=self.save()
        self.assertTrue(public['key_saved'])
        self.assertNotIn(self.secret,json.dumps(public))
        raw=llm.path_for(self.owner).read_text(encoding='utf-8')
        self.assertNotIn(self.secret,raw)
        import base64
        cfg=json.loads(raw)
        self.assertEqual(llm.crypt(base64.b64decode(cfg['protected_key']),decrypt=True).decode(),self.secret)
        self.assertFalse(llm.public_settings('e'*64)['key_saved'])

    def test_free_project_acknowledgement_required(self):
        with self.assertRaises(ValueError):
            self.save(free_project_confirmed=False)
        self.assertFalse(llm.load(self.owner).get('protected_key'))

    def test_system_context_is_preserved_as_one_instruction(self):
        messages=[dict(role='system',content='Today is 2026-11-23.'),dict(role='system',content='Reference snippets.'),dict(role='user',content='Question')]
        merged=llm.normalize_messages(messages)
        self.assertEqual(sum(m['role']=='system' for m in merged),1)
        self.assertIn('2026-11-23',merged[0]['content'])
        self.assertIn('Reference snippets',merged[0]['content'])

    def test_official_endpoint_reasoning_and_usage_contract(self):
        self.save()
        result=dict(choices=[dict(finish_reason='stop',message=dict(content='2'))],usage=dict(prompt_tokens=10,completion_tokens=4,total_tokens=14))
        with patch('llm_backend.urllib.request.urlopen',return_value=io.BytesIO(json.dumps(result).encode())) as send:
            self.assertEqual(llm.complete([dict(role='user',content='1+1')]),'2')
        request=send.call_args.args[0]
        body=json.loads(request.data)
        self.assertEqual(request.full_url,llm.ENDPOINT)
        self.assertEqual(body['model'],'gemini-3.5-flash-lite')
        self.assertEqual(body['reasoning_effort'],'high')
        self.assertNotIn('temperature',body)
        state=llm.public_settings(self.owner)
        self.assertTrue(state['verified'])
        self.assertEqual(state['requests_today'],1)
        self.assertEqual(state['usage']['total_tokens'],14)

    def test_quota_error_has_no_retry_or_fallback_and_redacts_body(self):
        self.save()
        error=urllib.error.HTTPError(llm.ENDPOINT,429,'limit',{},io.BytesIO(self.secret.encode()))
        with patch('llm_backend.urllib.request.urlopen',side_effect=error) as send,patch('llm_backend.local.infer') as fallback:
            with self.assertRaises(ValueError) as caught:
                llm.complete([dict(role='user',content='test')])
            self.assertEqual(send.call_count,1)
            fallback.assert_not_called()
            self.assertNotIn(self.secret,str(caught.exception))
            self.assertIn('자동 전환하지 않습니다',str(caught.exception))

    def test_daily_cap_stops_before_a_network_request(self):
        self.save(daily_limit=1)
        llm.reserve_call(self.owner)
        with patch('llm_backend.urllib.request.urlopen') as send:
            with self.assertRaises(ValueError):
                llm.complete([dict(role='user',content='test')])
            send.assert_not_called()

    def test_503_retries_same_model_and_counts_each_attempt(self):
        self.save()
        response=dict(choices=[dict(finish_reason='stop',message=dict(content='OK'))])
        error=urllib.error.HTTPError(llm.ENDPOINT,503,'unavailable',{},io.BytesIO(b'busy'))
        with patch('llm_backend.urllib.request.urlopen',side_effect=[error,io.BytesIO(json.dumps(response).encode())]) as send, patch('llm_backend.time.sleep'), patch('llm_backend.local.infer') as fallback:
            self.assertEqual(llm.complete([dict(role='user',content='test')]),'OK')
            self.assertEqual(send.call_count,2)
            self.assertIs(send.call_args_list[0].args[0],send.call_args_list[1].args[0])
            fallback.assert_not_called()
        self.assertEqual(llm.public_settings(self.owner)['requests_today'],2)

    def test_old_model_success_does_not_verify_replacement(self):
        self.save()
        cfg=llm.load(self.owner)
        cfg.update(model='gemini-4-hydrogen',verified=True)
        llm.persist(self.owner,cfg)
        self.assertFalse(llm.public_settings(self.owner)['verified'])

    def test_503_retries_stop_at_daily_cap(self):
        self.save(daily_limit=1)
        error=urllib.error.HTTPError(llm.ENDPOINT,503,'unavailable',{},io.BytesIO(b'busy'))
        with patch('llm_backend.urllib.request.urlopen',side_effect=error) as send, patch('llm_backend.time.sleep'):
            with self.assertRaisesRegex(ValueError,'하루 API 호출 한도'):
                llm.complete([dict(role='user',content='test')])
            self.assertEqual(send.call_count,1)

    def test_persistent_503_stops_after_three_attempts(self):
        self.save()
        errors=[urllib.error.HTTPError(llm.ENDPOINT,503,'unavailable',{},io.BytesIO(self.secret.encode())) for _ in range(3)]
        with patch('llm_backend.urllib.request.urlopen',side_effect=errors) as send, patch('llm_backend.time.sleep'), patch('llm_backend.local.infer') as fallback:
            with self.assertRaisesRegex(ValueError,'최대 2회 재시도') as caught:
                llm.complete([dict(role='user',content='test')])
            self.assertNotIn(self.secret,str(caught.exception))
            self.assertEqual(send.call_count,3)
            fallback.assert_not_called()
        self.assertEqual(llm.public_settings(self.owner)['requests_today'],3)

    def test_structured_plan_declares_schema_and_low_effort(self):
        self.save()
        schema={'type':'object','properties':{'action':{'type':'string'}}}
        response=dict(choices=[dict(finish_reason='stop',message=dict(content='{"action":"chat"}'))])
        with patch('llm_backend.urllib.request.urlopen',return_value=io.BytesIO(json.dumps(response).encode())) as send:
            llm.complete([dict(role='user',content='test')],schema=schema,effort='low')
        payload=json.loads(send.call_args.args[0].data)
        self.assertEqual(payload['response_format']['json_schema']['schema'],schema)
        self.assertEqual(payload['reasoning_effort'],'low')

    def test_truncated_response_is_not_saved_as_complete(self):
        self.save()
        response=dict(choices=[dict(finish_reason='length',message=dict(content='partial'))])
        with patch('llm_backend.urllib.request.urlopen',return_value=io.BytesIO(json.dumps(response).encode())):
            with self.assertRaises(ValueError):
                llm.complete([dict(role='user',content='test')])
        self.assertFalse(llm.public_settings(self.owner)['verified'])


if __name__=='__main__':
    unittest.main(verbosity=2)
