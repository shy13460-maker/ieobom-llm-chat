"""Package a clean source release; never include visitor data, models, logs or local environments."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'outputs'


def main():
    sources=[]
    for path in sorted((ROOT/'upstream').rglob('*')):
        if path.is_file():
            sources.append(dict(file=path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    metadata=dict(snapshot_date='2026-11-23',repositories=[
        'https://github.com/shy13460-maker/Regression-Analysis-Tool',
        'https://github.com/shy13460-maker/ANN-Prediction-Analyzer',
        'https://github.com/shy13460-maker/ieobom-llm-chat'],files=sources,
        note='Downloaded source snapshots are retained under upstream. Hashes identify the actual reviewed files; remote HEAD may change.')
    (ROOT/'SOURCES.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    top=['app.py','agent.py','llm_backend.py','web_search.py','memory_chat.py','start.py','install_model.py','prepare_sources.py','build_release.py',
         'INSTALL.cmd','INSTALL_MODEL.cmd','START.cmd','setup.ps1','launch.ps1','README.md','REPORT_V2.md','사용설명.html','VALIDATION.md',
         'requirements.txt','requirements-lock.txt','config.example.json','.gitignore','SOURCES.json']
    paths=[ROOT/name for name in top]
    for folder in ('analysis','web','examples'):
        paths.extend(p for p in (ROOT/folder).iterdir() if p.is_file() and p.suffix in ('.py','.js','.css','.html','.csv'))
    paths.append(ROOT/'tests/test_analysis.py')
    paths.append(ROOT/'tests/test_llm_backend.py')
    paths.append(ROOT/'tests/test_web_search.py')
    paths.append(ROOT/'tests/test_workflow.py')
    # Keep exact original source snapshots as reference, including the files used by prepare_sources.py.
    paths.extend(p for p in (ROOT/'upstream').rglob('*') if p.is_file())
    for filename in ('통합AI_회귀_API실행.png', '통합AI_ANN_API실행.png', '통합AI_무료웹검색_성공.png', '통합AI_동일조건비교_성공.png'):
        preview=ROOT/filename
        if preview.exists():
            paths.append(preview)
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
    OUT.mkdir(exist_ok=True)
    target=OUT/'이어봄_AI_v2.0_통합과제AI.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
        for path in sorted(set(paths)):
            archive.write(path,'Ieobom_AI_2_0/'+path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        bad=[name for name in archive.namelist() if any(part in name.split('/') for part in ('data','.venv','models','runtime','logs','artifacts'))]
        if bad or archive.testzip():
            raise RuntimeError('Package integrity or clean-content verification failed')
        print(json.dumps(dict(path=str(target),files=len(archive.namelist()),bytes=target.stat().st_size,
                              sha256=hashlib.sha256(target.read_bytes()).hexdigest()),ensure_ascii=False))


if __name__=='__main__':
    main()
