"""Explicit local/Gemini selection. No automatic provider or paid-model fallback."""
from __future__ import annotations
import base64
from contextvars import ContextVar
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone, timedelta
import memory_chat as local

ROOT = Path(__file__).resolve().parent
OWNER = ContextVar('llm_owner', default=None)
MODEL = 'gemini-3.5-flash-lite'
ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'
LOCK = threading.RLock()


def path_for(owner):
    if not isinstance(owner, str) or len(owner) != 64 or any(c not in '0123456789abcdef' for c in owner):
        raise ValueError('사용자 정보를 확인할 수 없습니다.')
    directory = ROOT/'data/llm'
    directory.mkdir(parents=True, exist_ok=True)
    return directory/(owner+'.json')


def load(owner=None):
    owner = owner or OWNER.get()
    if not owner:
        return dict(provider='gemini')
    path = path_for(owner)
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else dict(provider='gemini')


def persist(owner, cfg):
    path = path_for(owner)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def crypt(data, decrypt=False):
    """Windows DPAPI binds saved secrets to this OS user; no plaintext key file."""
    if os.name != 'nt':
        raise ValueError('이 설치본의 API 키 저장은 Windows에서 지원합니다.')
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    target = Blob()
    api = ctypes.windll.crypt32
    if decrypt:
        ok = api.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target))
    else:
        ok = api.CryptProtectData(ctypes.byref(source), ctypes.c_wchar_p('Ieobom Gemini API'), None, None, None, 1, ctypes.byref(target))
    if not ok:
        raise ValueError('API 키를 보호하거나 읽지 못했습니다. 이 PC에서 키를 다시 입력해 주세요.')
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        ctypes.windll.kernel32.LocalFree(ctypes.cast(target.data, ctypes.c_void_p))


def public_settings(owner):
    cfg = load(owner)
    today = datetime.now(timezone(timedelta(hours=9))).date().isoformat()
    return dict(provider=cfg.get('provider','local'), model=MODEL if cfg.get('provider')=='gemini' else local.MODEL,
        key_saved=bool(cfg.get('protected_key')), verified=bool(cfg.get('verified')) and cfg.get('model')==MODEL,
        thinking=cfg.get('thinking','high'), daily_limit=cfg.get('daily_limit',20),
        requests_today=cfg.get('requests',0) if cfg.get('day')==today else 0,
        usage=cfg.get('usage',{}), fallback=False)


def save_settings(owner, data):
    if data.get('provider') not in ('local','gemini'):
        raise ValueError('지원하는 연결 방식을 선택해 주세요.')
    cfg = load(owner)
    if data['provider']=='local':
        cfg['provider']='local'
    else:
        if data.get('free_project_confirmed') is not True:
            raise ValueError('Google AI Studio에서 프로젝트가 무료 등급인지 확인해 주세요.')
        if data.get('thinking','high') not in ('low','medium','high'):
            raise ValueError('추론 수준을 확인해 주세요.')
        try:
            limit=int(data.get('daily_limit',20))
        except (TypeError,ValueError):
            raise ValueError('하루 API 호출 제한을 확인해 주세요.')
        if not 1 <= limit <= 200:
            raise ValueError('하루 API 호출은 1~200회 범위로 제한해 주세요.')
        key=data.get('api_key','')
        if not isinstance(key,str):
            raise ValueError('API 키 형식을 확인해 주세요.')
        key=key.strip()
        if key:
            if not 15 <= len(key) <= 512 or any(c.isspace() for c in key):
                raise ValueError('API 키 형식을 확인해 주세요.')
            cfg['protected_key']=base64.b64encode(crypt(key.encode())).decode()
            cfg['verified']=False
        if not cfg.get('protected_key'):
            raise ValueError('먼저 본인의 Gemini API 키를 입력해 주세요.')
        cfg.update(provider='gemini', model=MODEL, thinking=data.get('thinking','high'),
            daily_limit=limit, free_project_confirmed=True)
    with LOCK:
        persist(owner,cfg)
    return public_settings(owner)


def model_name():
    return MODEL if load().get('provider')=='gemini' else local.MODEL


def normalize_messages(messages):
    # Preserve every instruction when the provider exposes one system instruction.
    instructions = [m['content'] for m in messages if m.get('role')=='system']
    rest = [m for m in messages if m.get('role')!='system']
    return ([dict(role='system',content='\n\n'.join(instructions))] if instructions else []) + rest


def reserve_call(owner):
    with LOCK:
        cfg=load(owner)
        today=datetime.now(timezone(timedelta(hours=9))).date().isoformat()
        if cfg.get('day')!=today:
            cfg.update(day=today,requests=0,usage={})
        if cfg.get('requests',0)>=cfg.get('daily_limit',20):
            raise ValueError('앱에서 설정한 하루 API 호출 한도에 도달했습니다. 다른 모델로 자동 전환하지 않습니다.')
        cfg['requests']=cfg.get('requests',0)+1
        persist(owner,cfg)
        return cfg


def complete(messages, limit=900, schema=None, effort=None):
    cfg=load()
    if cfg.get('provider')!='gemini':
        if schema is None:
            return local.infer(messages,limit)
        payload=dict(model=local.MODEL,messages=messages,stream=False,think=False,format=schema,
            keep_alive='10m',options=dict(temperature=0,num_ctx=4096,num_predict=limit))
        request=urllib.request.Request(local.OLLAMA+'/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=240) as response:
            return json.load(response)['message']['content']
    owner=OWNER.get()
    if not owner or not cfg.get('free_project_confirmed') or not cfg.get('protected_key'):
        raise ValueError('AI 연결 설정에서 무료 프로젝트의 Gemini API 키를 입력해 주세요.')
    cfg=reserve_call(owner)
    key=crypt(base64.b64decode(cfg['protected_key']),decrypt=True).decode()
    payload=dict(model=MODEL,messages=normalize_messages(messages),stream=False,
        reasoning_effort=effort or cfg.get('thinking','high'),max_tokens=8192 if schema else 16384)
    if schema is not None:
        payload['response_format']=dict(type='json_schema',json_schema=dict(name='analysis_plan',schema=schema))
    request=urllib.request.Request(ENDPOINT,data=json.dumps(payload,ensure_ascii=False).encode(),
        headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
    try:
        for attempt in range(3):
            try:
                with urllib.request.urlopen(request,timeout=240) as response:
                    obj=json.load(response)
                break
            except urllib.error.HTTPError as transient:
                if transient.code != 503 or attempt == 2:
                    transient.close()
                    raise
                transient.close()
                time.sleep(2 ** attempt)
                # Every retry stays on the same model and consumes the local daily cap.
                reserve_call(owner)
    except urllib.error.HTTPError as exc:
        # Never echo provider response bodies, request headers or credentials.
        if exc.code==429:
            raise ValueError('Gemini 무료 할당량 또는 요청 속도 제한에 도달했습니다. 잠시 후 다시 시도하세요. 유료 모델로 자동 전환하지 않습니다.') from None
        if exc.code in (401,403):
            raise ValueError('Google API 키 또는 프로젝트 권한을 확인해 주세요. 무료 등급 이용 가능 여부도 AI Studio에서 확인하세요.') from None
        if exc.code==404:
            raise ValueError('현재 프로젝트에서 Gemini 3.5 Flash-Lite를 사용할 수 없습니다. 모델 이용 가능 여부를 AI Studio에서 확인하세요.') from None
        if exc.code==503:
            raise ValueError('제미나이 서버가 일시적으로 응답하지 않습니다. 같은 모델로 최대 2회 재시도했지만 실패했습니다. 잠시 후 다시 보내 주세요. 다른 모델이나 유료 요금제로 전환하지 않았습니다.') from None
        raise ValueError(f'Gemini 요청을 처리하지 못했습니다. (HTTP {exc.code}) 다른 모델로 자동 전환하지 않습니다.') from None
    except (OSError,json.JSONDecodeError):
        raise ValueError('Google AI 서버에 연결하지 못했습니다. 인터넷 연결을 확인해 주세요. 자동 재호출은 하지 않았습니다.') from None
    choices=obj.get('choices') or []
    if not choices:
        raise ValueError('Gemini가 답변을 반환하지 않았습니다. 요청을 다시 확인해 주세요.')
    choice=choices[0]
    text=choice.get('message',{}).get('content') or ''
    if not isinstance(text,str) or not text.strip():
        raise ValueError('추론 중 답변 생성이 종료되었습니다. 요청을 짧게 하거나 추론 수준을 낮춰 주세요.')
    if choice.get('finish_reason')=='length':
        raise ValueError('추론과 답변이 설정한 출력 길이를 초과했습니다. 요청을 나누거나 추론 수준을 낮춰 주세요.')
    with LOCK:
        updated=load(owner)
        usage=updated.setdefault('usage',{})
        for field in ('prompt_tokens','completion_tokens','total_tokens'):
            usage[field]=usage.get(field,0)+int((obj.get('usage') or {}).get(field,0))
        updated['verified']=True
        updated['model']=MODEL
        updated['last_success']=time.time()
        persist(owner,updated)
    return text.strip()
