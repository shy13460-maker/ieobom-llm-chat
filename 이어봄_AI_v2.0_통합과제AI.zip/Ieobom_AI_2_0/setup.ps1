$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$pythonCandidates = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
    (Join-Path $projectRoot 'runtime\python\python.exe')
)
$pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
if ($pythonCommand) { $pythonCandidates += $pythonCommand.Source }
$pythonPath = $null
foreach ($candidate in $pythonCandidates) {
    if (Test-Path -LiteralPath $candidate) {
        & $candidate -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,12) else 1)" 2>$null
        if ($LASTEXITCODE -eq 0) { $pythonPath = $candidate; break }
    }
}
if (-not $pythonPath) {
    $runtimePath = Join-Path $projectRoot 'runtime'
    New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
    $installerPath = Join-Path $runtimePath 'python-3.12.10-amd64.exe'
    Write-Host 'Downloading Python 3.12.10 from python.org...'
    Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $installerPath
    $pythonTarget = Join-Path $runtimePath 'python'
    $installArguments = @('/quiet', 'InstallAllUsers=0', ('TargetDir="' + $pythonTarget + '"'), 'Include_launcher=0', 'Include_test=0', 'PrependPath=0', 'Shortcuts=0')
    $installation = Start-Process -FilePath $installerPath -ArgumentList $installArguments -WindowStyle Hidden -Wait -PassThru
    if ($installation.ExitCode -ne 0 -and $installation.ExitCode -ne 3010) { throw 'Python installation failed.' }
    $pythonPath = Join-Path $pythonTarget 'python.exe'
}
$hashBytes = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($projectRoot))
$projectKey = ([BitConverter]::ToString($hashBytes)).Replace('-', '').Substring(0, 12).ToLowerInvariant()
$environmentRoot = Join-Path $env:LOCALAPPDATA ('IeobomAI\envs\' + $projectKey)
$venvPython = Join-Path $environmentRoot 'Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $environmentRoot) -Force | Out-Null
    & $pythonPath -m venv $environmentRoot
    if ($LASTEXITCODE -ne 0) { throw 'Could not create Python environment.' }
}
Write-Host 'Installing analysis libraries into this project...'
& $venvPython -m pip install -r (Join-Path $projectRoot 'requirements-lock.txt')
if ($LASTEXITCODE -ne 0) { throw 'Library installation failed.' }
& $venvPython -c "import numpy,pandas,scipy,sklearn,tensorflow,openpyxl; print('Analysis environment ready.')"
if ($LASTEXITCODE -ne 0) { throw 'Library verification failed.' }
[IO.File]::WriteAllText((Join-Path $projectRoot 'PYTHON_PATH.txt'), $venvPython, [Text.UTF8Encoding]::new($false))
if (-not (Get-Command pwsh -ErrorAction SilentlyContinue)) {
    $searchRuntime = Join-Path $projectRoot 'runtime\powershell'
    if (-not (Test-Path -LiteralPath (Join-Path $searchRuntime 'pwsh.exe'))) {
        Write-Host 'Preparing free Microsoft PowerShell 7 for web search...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $releaseInfo = Invoke-RestMethod -Uri 'https://api.github.com/repos/PowerShell/PowerShell/releases/latest'
        $searchAsset = $releaseInfo.assets | Where-Object { $_.name -match '^PowerShell-[0-9.]+-win-x64\.zip$' } | Select-Object -First 1
        if (-not $searchAsset -or -not $searchAsset.browser_download_url.StartsWith('https://github.com/PowerShell/PowerShell/releases/download/')) { throw 'Official search runtime download not found.' }
        New-Item -ItemType Directory -Path $searchRuntime -Force | Out-Null
        $searchArchive = Join-Path $projectRoot 'runtime\powershell.zip'
        Invoke-WebRequest -Uri $searchAsset.browser_download_url -OutFile $searchArchive -UseBasicParsing
        if ($searchAsset.digest -like 'sha256:*') {
            $downloadHash = (Get-FileHash -LiteralPath $searchArchive -Algorithm SHA256).Hash.ToLowerInvariant()
            if ('sha256:'+$downloadHash -ne $searchAsset.digest) { throw 'Search runtime checksum mismatch.' }
        }
        Expand-Archive -LiteralPath $searchArchive -DestinationPath $searchRuntime -Force
        if (-not (Test-Path -LiteralPath (Join-Path $searchRuntime 'pwsh.exe'))) { throw 'Search runtime setup failed.' }
    }
}

Write-Host 'Ready. Run START.cmd.'
