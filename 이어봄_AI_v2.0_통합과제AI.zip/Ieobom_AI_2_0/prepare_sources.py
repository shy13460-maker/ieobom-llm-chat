"""Extract calculation definitions from the user's original submissions, without UI side effects."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
dest = ROOT / 'analysis'
dest.mkdir(exist_ok=True)
(dest / '__init__.py').write_text('', encoding='utf-8')

source = (ROOT / 'upstream/Regression-Analysis-Tool/Regression_Analyzer_Web.py').read_text(encoding='utf-8-sig')
tree = ast.parse(source)
keep = []
for node in tree.body:
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        # Plotly and Streamlit belong to the old presentation layer.
        names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or '']
        if any(n.startswith(('streamlit', 'plotly')) for n in names):
            continue
        keep.append(node)
    elif isinstance(node, (ast.FunctionDef, ast.ClassDef)):
        if node.name not in ('regression_figure', 'residual_figure', 'render_algorithm_overview'):
            keep.append(node)
    elif isinstance(node, (ast.Assign, ast.AnnAssign)):
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if all(isinstance(t, ast.Name) and t.id in ('APP_TITLE', 'NONE', 'MODELS') for t in targets):
            keep.append(node)
(dest / 'regression_core.py').write_text('# Extracted from Regression-Analysis-Tool; see SOURCES.json.\n' + ast.unparse(ast.Module(body=keep, type_ignores=[])) + '\n', encoding='utf-8')

source = (ROOT / 'upstream/ANN-Prediction-Analyzer/ANN_Prediction_Analyzer.py').read_text(encoding='utf-8-sig')
tree = ast.parse(source)
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'build_model']
(dest / 'ann_core.py').write_text('"""Original ANN architecture extracted from the submitted program."""\nimport tensorflow as tf\n\n' + ast.unparse(ast.Module(body=nodes, type_ignores=[])) + '\n', encoding='utf-8')

# Preserve the original conversation and memory implementation separately.
source = (ROOT / 'upstream/ieobom-llm-chat/app.py').read_text(encoding='utf-8-sig')
source = source.replace("ROOT = Path(__file__).resolve().parent", "ROOT = Path(__file__).resolve().parent")
source = source.replace("OLLAMA = 'http://127.0.0.1:11435'", "OLLAMA = os.environ.get('OLLAMA_URL', 'http://127.0.0.1:11435').rstrip('/')")
(ROOT / 'memory_chat.py').write_text(source, encoding='utf-8')
print('Extracted original regression, ANN architecture and conversation/memory modules.')
