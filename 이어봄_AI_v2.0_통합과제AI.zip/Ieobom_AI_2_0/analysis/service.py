"""Real numerical tools. Model text is never evaluated as Python or a shell command."""
from __future__ import annotations
import hashlib
import datetime
import io
import json
import math
import os
from pathlib import Path
import secrets
import threading
import time

os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
os.environ.setdefault('CUDA_VISIBLE_DEVICES', '-1')  # Leave VRAM to the local LLM.
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '2')
os.environ.setdefault('TF_NUM_INTEROP_THREADS', '2')
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from . import regression_core as reg

ROOT = Path(__file__).resolve().parents[1]
TRAIN_LOCK = threading.Lock()
MAX_ROWS = 20000
DEFAULTS = dict(hidden_units=16, activation='relu', learning_rate=0.001, l2=0.0001,
                epochs=300, batch_size=16, patience=40, test_ratio=0.20,
                validation_ratio=0.15, seed=42)


def clean_json(value):
    if value is pd.NA or value is pd.NaT:
        return None
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [clean_json(v) for v in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def write_json(path, value):
    path.write_text(json.dumps(clean_json(value), ensure_ascii=False, allow_nan=False), encoding='utf-8')


def owned_dir(owner):
    if len(owner) != 64 or any(c not in '0123456789abcdef' for c in owner):
        raise ValueError('방문자 정보가 올바르지 않습니다.')
    path = ROOT / 'data' / 'analysis' / owner
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_id(value):
    if not isinstance(value, str) or len(value) != 32 or any(c not in '0123456789abcdef' for c in value):
        raise ValueError('자료 ID가 올바르지 않습니다.')
    return value


def dataset(owner, did):
    path = owned_dir(owner) / (safe_id(did) + '.dataset.json')
    if not path.exists():
        raise ValueError('데이터를 찾을 수 없습니다. 파일을 다시 선택해 주세요.')
    obj = json.loads(path.read_text(encoding='utf-8'))
    return obj, pd.read_json(io.StringIO(obj['frame']), orient='split')


def describe(owner, did):
    obj, frame = dataset(owner, did)
    numeric = [c for c in frame if pd.to_numeric(frame[c], errors='coerce').notna().sum() >= 3]
    return clean_json(dict(id=did, name=obj['name'], rows=len(frame), columns=list(frame.columns),
                           numeric=numeric, preview=frame.head(8).where(frame.notna(), None).to_dict('records'),
                           sha256=obj['sha256']))


def upload(owner, name, data, header=1, sheet=None):
    if len(data) > 8 * 1024 * 1024:
        raise ValueError('파일은 8MB 이내로 업로드해 주세요.')
    if len(list(owned_dir(owner).glob('*.dataset.json'))) >= 60:
        raise ValueError('저장된 데이터가 60개입니다. 새 작업 폴더를 사용하거나 운영자에게 정리를 요청하세요.')
    suffix = Path(name).suffix.lower()
    if suffix == '.csv':
        try:
            raw = pd.read_csv(io.BytesIO(data), header=None, encoding='utf-8-sig', nrows=MAX_ROWS + 30)
        except UnicodeDecodeError:
            raw = pd.read_csv(io.BytesIO(data), header=None, encoding='cp949', nrows=MAX_ROWS + 30)
    elif suffix in ('.xlsx', '.xls'):
        raw = pd.read_excel(io.BytesIO(data), header=None, sheet_name=sheet or 0, nrows=MAX_ROWS + 30)
    else:
        raise ValueError('CSV, XLSX, XLS 파일만 지원합니다.')
    if raw.shape[1] > 100:
        raise ValueError('열은 최대 100개까지 지원합니다.')
    frame = reg.apply_header(raw, int(header))
    if len(frame) > MAX_ROWS or len(frame) < 4:
        raise ValueError('데이터는 4~20,000행 범위여야 합니다.')
    if len(set(frame.columns)) != len(frame.columns):
        raise ValueError('중복된 열 이름을 정리해 주세요.')
    did = secrets.token_hex(16)
    write_json(owned_dir(owner) / (did + '.dataset.json'),
               dict(name=Path(name.replace('\\', '/')).name[:100], sha256=hashlib.sha256(data).hexdigest(),
                    frame=frame.to_json(orient='split', force_ascii=False), created=time.time()))
    return describe(owner, did)


def sample(owner):
    return upload(owner, 'Yacht_Hydrodynamics.csv', (ROOT / 'examples/yacht.csv').read_bytes())


def ann_sample(owner):
    from sklearn.datasets import load_diabetes
    frame = load_diabetes(as_frame=True, scaled=False).frame.rename(columns={
        'age':'Age', 'sex':'Sex_Code', 'bmi':'BMI', 'bp':'Blood_Pressure', 's1':'Total_Cholesterol',
        's2':'LDL', 's3':'HDL', 's4':'Cholesterol_HDL_Ratio', 's5':'Log_Triglycerides',
        's6':'Blood_Sugar', 'target':'Disease_Progression'})
    return upload(owner, 'ANN_Practice_Diabetes.csv', frame.to_csv(index=False).encode('utf-8-sig'))


def load_result(owner, rid):
    path = owned_dir(owner) / (safe_id(rid) + '.result.json')
    if not path.exists():
        raise ValueError('분석 결과를 찾을 수 없습니다.')
    return json.loads(path.read_text(encoding='utf-8'))


def list_results(owner, did=None):
    rows = []
    for path in owned_dir(owner).glob('*.result.json'):
        r = json.loads(path.read_text(encoding='utf-8'))
        if did is None or r['dataset'] == did:
            rows.append({k: r[k] for k in ('id', 'dataset', 'kind', 'title', 'created')})
    return sorted(rows, key=lambda r: r['created'], reverse=True)


def save_result(owner, result, did):
    result.update(id=secrets.token_hex(16), dataset=did, created=time.time(), version='2.0.0')
    result = clean_json(result)
    write_json(owned_dir(owner) / (result['id'] + '.result.json'), result)
    return result


def numeric_frame(frame, columns):
    if not columns or len(set(columns)) != len(columns) or any(c not in frame.columns for c in columns):
        raise ValueError('입력 변수와 예측 대상을 확인해 주세요. 같은 열을 중복 선택할 수 없습니다.')
    numeric = frame[columns].apply(pd.to_numeric, errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
    if len(numeric) < 8:
        raise ValueError('선택한 열에 유효한 수치 데이터가 8행 이상 필요합니다.')
    if numeric[columns[-1]].nunique() < 2:
        raise ValueError('예측 대상 값이 모두 같습니다. 다른 열을 선택해 주세요.')
    return numeric


def run_regression(owner, did, cfg, save=True):
    obj, frame = dataset(owner, did)
    x, y = cfg.get('x'), cfg.get('y')
    y_error = cfg.get('y_error') or None
    if y_error and y_error not in frame.columns:
        raise ValueError('Y 오차막대 열을 확인해 주세요.')
    group = cfg.get('group') or reg.NONE
    if group != reg.NONE and group not in frame:
        raise ValueError('그룹 열을 확인해 주세요.')
    models = cfg.get('models', list(reg.MODELS))
    if not isinstance(models, list) or not models or any(m not in reg.MODELS for m in models):
        raise ValueError('지원하는 회귀모델을 선택해 주세요.')
    numeric_frame(frame, [x, y])
    results, failures, curves = [], [], []
    for case, part in reg.analysis_groups(frame, group):
        if len(curves) > 100:
            raise ValueError('그룹이 너무 많습니다. 그룹을 15개 이하로 줄여 주세요.')
        xx = pd.to_numeric(part[x], errors='coerce').to_numpy(dtype=float)
        yy = pd.to_numeric(part[y], errors='coerce').to_numpy(dtype=float)
        for model in models:
            try:
                r = reg.fit_model(case, model, xx, yy)
                grid = np.linspace(float(r.x.min()), float(r.x.max()), 160)
                lo, hi = reg.confidence_band(r, grid)
                error_y = None
                if y_error:
                    valid = np.isfinite(xx) & np.isfinite(yy)
                    if model in ('Logarithmic','Power'):
                        valid &= xx > 0
                    values = pd.to_numeric(part[y_error],errors='coerce').to_numpy(dtype=float)[valid]
                    error_y = [float(v) if np.isfinite(v) and v>=0 else None for v in values[:2000]]
                curves.append(dict(case=case, model=model, x=grid, y=r.predict(grid), lower=lo, upper=hi,
                                   actual_x=r.x[:2000], actual_y=r.y[:2000], residuals=r.residuals[:2000],error_y=error_y,
                                   outliers=r.outlier_mask[:2000]))
                results.append(r)
            except Exception as exc:
                failures.append(dict(case=case, model=model, reason=str(exc)[:200]))
    if not results:
        raise ValueError('모든 회귀모델의 적합에 실패했습니다. 데이터와 모델을 확인해 주세요.')
    summary = reg.build_summary_df(results).to_dict('records')
    r = dict(kind='regression', title=f'{x} → {y} · 회귀분석', config=dict(x=x, y=y, group=group, models=models,y_error=y_error),
             summary=summary, curves=curves, parameters=reg.build_parameter_df(results).to_dict('records'),
             predictions=reg.build_predictions_df(results).to_dict('records'),
             residuals=reg.build_best_residual_df(results).to_dict('records'), failures=failures,
             evidence=dict(algorithm='numpy.polyfit / scipy.optimize.curve_fit(method=trf)',
                           selection='그룹별 AICc, 계산 불가 시 AIC', evaluation='적합에 사용한 데이터에서 계산한 지표',
                           interval='파라미터 공분산과 t 분포 기반 회귀 평균의 근사 95% 신뢰구간; 예측구간과 다름',
                           error_bars='Y 오차는 표시용이며 적합 가중치로 사용하지 않음',
                           source='Regression-Analysis-Tool/Regression_Analyzer_Web.py'))
    r['evidence']['dataset_sha256'] = obj['sha256']
    return save_result(owner, r, did) if save else r


def settings(cfg):
    out = DEFAULTS.copy()
    out.update({k: cfg[k] for k in DEFAULTS if k in cfg})
    for k, low, high in [('hidden_units', 1, 256), ('epochs', 1, 1000), ('batch_size', 4, 256), ('patience', 2, 150), ('seed', 0, 9999)]:
        if isinstance(out[k], bool) or int(out[k]) != float(out[k]) or not low <= int(out[k]) <= high:
            raise ValueError(f'{k}: {low}~{high} 범위의 정수가 필요합니다.')
        out[k] = int(out[k])
    for k, low, high in [('learning_rate', 0.00001, 0.05), ('l2', 0, 0.1), ('test_ratio', .1, .3), ('validation_ratio', .1, .25)]:
        out[k] = float(out[k])
        if not low <= out[k] <= high:
            raise ValueError(f'{k} 설정 범위를 확인해 주세요.')
    if out['test_ratio'] + out['validation_ratio'] >= .5:
        raise ValueError('검증과 테스트 비율의 합은 50% 미만이어야 합니다.')
    if out['activation'] not in ('relu', 'tanh', 'sigmoid'):
        raise ValueError('활성화 함수를 확인해 주세요.')
    return out


def split_indices(n, cfg):
    trainval, test = train_test_split(np.arange(n), test_size=cfg['test_ratio'], random_state=cfg['seed'])
    train, val = train_test_split(trainval, test_size=cfg['validation_ratio']/(1-cfg['test_ratio']), random_state=cfg['seed'])
    if min(len(train), len(val), len(test)) < 2:
        raise ValueError('분할 후 각 데이터에 2행 이상 필요합니다. 데이터를 추가해 주세요.')
    return train, val, test


def metrics(y, pred):
    return dict(R2=float(r2_score(y, pred)), RMSE=math.sqrt(mean_squared_error(y, pred)), MAE=float(mean_absolute_error(y, pred)))


def train_ann(owner, did, cfg, progress=lambda text: None):
    from .ann_core import build_model
    import tensorflow as tf
    conf = settings(cfg)
    features, target = cfg.get('features'), cfg.get('y')
    if not isinstance(features, list) or not features or len(features) > 30:
        raise ValueError('입력 변수는 1~30개 선택해 주세요.')
    obj, frame = dataset(owner, did)
    work = numeric_frame(frame, features + [target])
    X, y = work[features].to_numpy(dtype=np.float32), work[[target]].to_numpy(dtype=np.float32)
    if not np.isfinite(X).all() or not np.isfinite(y).all():
        raise ValueError('숫자의 범위가 너무 큽니다. 데이터 단위를 조정해 주세요.')
    train, val, test = split_indices(len(work), conf)
    xs, ys = StandardScaler(), StandardScaler()
    xtrain, ytrain = xs.fit_transform(X[train]), ys.fit_transform(y[train])
    xval, yval = xs.transform(X[val]), ys.transform(y[val])
    class Progress(tf.keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            if not np.isfinite((logs or {}).get('loss', np.nan)):
                self.model.stop_training = True
            if epoch % 10 == 0:
                progress(f'ANN 학습 {epoch+1}/{conf["epochs"]} epoch · 검증 손실 {(logs or {}).get("val_loss", 0):.5g}')
    with TRAIN_LOCK:
        tf.keras.backend.clear_session()
        tf.keras.utils.set_random_seed(conf['seed'])
        model = build_model(len(features), conf['hidden_units'], conf['activation'], conf['learning_rate'], conf['l2'])
        callbacks = [tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=conf['patience'], min_delta=1e-5, restore_best_weights=True),
                     tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=.5, patience=max(5, conf['patience']//3), min_lr=1e-6), Progress()]
        hist = model.fit(xtrain, ytrain, validation_data=(xval, yval), epochs=conf['epochs'],
                         batch_size=conf['batch_size'], callbacks=callbacks, verbose=0).history
        predict = lambda idx: ys.inverse_transform(model(xs.transform(X[idx]), training=False).numpy()).ravel()
        pred, valpred, trainpred = predict(test), predict(val), predict(train)
        if not np.isfinite(pred).all() or not all(np.isfinite(v) for v in hist['loss'] + hist['val_loss']):
            raise ValueError('학습 중 수치가 발산했습니다. 학습률이나 데이터 단위를 조정해 주세요.')
        weights = [w.tolist() for w in model.get_weights()]
        count = model.count_params()
    baseline = LinearRegression().fit(X[train], y[train].ravel())
    bp = baseline.predict(X[test])
    r = dict(kind='ann', title=f'{len(features)}개 입력 → {target} · ANN',
             config=dict(**conf, features=features, y=target), metrics=metrics(y[test].ravel(), pred),
             train_metrics=metrics(y[train].ravel(), trainpred),
             validation_metrics=metrics(y[val].ravel(), valpred), baseline=metrics(y[test].ravel(), bp), history=hist,
             actual_epochs=len(hist['loss']), best_epoch=int(callbacks[0].best_epoch)+1, parameters_count=count,
             stop_reason='early_stopping' if len(hist['loss']) < conf['epochs'] else 'max_epochs',
             split=dict(train=train, validation=val, test=test, source_rows=work.index.to_numpy()),
             scaler=dict(x_mean=xs.mean_, x_scale=xs.scale_, y_mean=ys.mean_, y_scale=ys.scale_), weights=weights,
             ranges={f: [float(X[train, i].min()), float(X[train, i].max())] for i, f in enumerate(features)},
             predictions=[dict(Actual=float(a), ANN_Predicted=float(p), Residual=float(a-p), Linear_Baseline=float(b))
                          for a, p, b in zip(y[test].ravel(), pred, bp)],
             standardization=dict(raw=X[train[:8]], scaled=xtrain[:8]),
             removed_rows=len(frame)-len(work), evidence=dict(source='ANN-Prediction-Analyzer/ANN_Prediction_Analyzer.py',
                 architecture=f'{len(features)} → Dense({conf["hidden_units"]}) → {conf["activation"]} → Dense(1, linear)',
                 loss='MSE + hidden kernel L2', optimizer='Adam', training='CPU; 역전파, EarlyStopping(best weights), ReduceLROnPlateau',
                 scaling='Train 데이터에서만 X/Y 평균·표준편차 적합', evaluation='검증 데이터로 학습 제어; Test는 최종 평가',
                 dataset_sha256=obj['sha256']))
    progress('학습 완료 · 결과 저장 중')
    return save_result(owner, r, did)


def predict_ann(result, inputs):
    cfg, s = result['config'], result['scaler']
    try:
        raw = np.array([[float(inputs[f]) for f in cfg['features']]], dtype=float)
    except (KeyError, TypeError, ValueError):
        raise ValueError('모든 입력 변수에 숫자를 입력해 주세요.')
    if not np.isfinite(raw).all():
        raise ValueError('입력값에 유한한 숫자가 필요합니다.')
    x = (raw - s['x_mean']) / s['x_scale']
    w1, b1, w2, b2 = [np.asarray(v) for v in result['weights']]
    z = x @ w1 + b1
    h = np.maximum(z, 0) if cfg['activation'] == 'relu' else np.tanh(z) if cfg['activation'] == 'tanh' else 1 / (1 + np.exp(-np.clip(z, -700, 700)))
    value = float(((h @ w2 + b2) * s['y_scale'] + s['y_mean'])[0, 0])
    outside = [f for i, f in enumerate(cfg['features']) if not result['ranges'][f][0] <= raw[0, i] <= result['ranges'][f][1]]
    return dict(value=value, target=cfg['y'], outside=outside)


def predict_result(owner, rid, inputs, model=None, case=None):
    r = load_result(owner, rid)
    if r['kind'] == 'ann':
        return predict_ann(r, inputs)
    if r['kind'] != 'regression':
        raise ValueError('회귀분석 또는 ANN 결과를 선택해 주세요.')
    candidates = [s for s in r['summary'] if case is None or s['Case'] == case]
    if not candidates:
        raise ValueError('선택한 그룹의 회귀 결과가 없습니다.')
    chosen = next((s for s in candidates if s['Model'] == model), None) if model else next((s for s in candidates if s['Best']), candidates[0])
    if chosen is None:
        raise ValueError('선택한 회귀모델 결과가 없습니다.')
    x = float(inputs[r['config']['x']])
    if not math.isfinite(x):
        raise ValueError('유한한 숫자를 입력해 주세요.')
    params = [p['Estimate'] for p in r['parameters'] if p['Case'] == chosen['Case'] and p['Model'] == chosen['Model']]
    spec = reg.MODELS[chosen['Model']]
    if spec.positive_x and x <= 0:
        raise ValueError('이 모델은 X > 0인 값만 예측할 수 있습니다.')
    value = float(spec.function(np.array([x]), *params)[0])
    if not math.isfinite(value):
        raise ValueError('예측값이 수치 범위를 벗어났습니다.')
    curve = next(c for c in r['curves'] if c['case'] == chosen['Case'] and c['model'] == chosen['Model'])
    return dict(value=value, target=r['config']['y'], case=chosen['Case'], model=chosen['Model'],
                outside=[r['config']['x']] if not min(curve['actual_x']) <= x <= max(curve['actual_x']) else [])


def compare(owner, did, cfg, progress=lambda text: None):
    # Refit every candidate on exactly the ANN training rows. Choose by validation, not test.
    if len(cfg.get('features') or []) != 1:
        raise ValueError('곡선 회귀와 ANN의 동일 조건 비교는 입력 변수 1개로 실행해 주세요.')
    ann = train_ann(owner, did, cfg, progress)
    _, frame = dataset(owner, did)
    features = ann['config']['features']
    if len(features) != 1:
        raise ValueError('곡선 회귀와 ANN의 동일 조건 비교는 입력 변수 1개로 실행해 주세요.')
    work = numeric_frame(frame, features + [cfg['y']])
    x = work[features[0]].to_numpy(dtype=float)
    y = work[cfg['y']].to_numpy(dtype=float)
    tr, va, te = [np.array(ann['split'][k]) for k in ('train', 'validation', 'test')]
    fitted, failures = [], []
    for name in cfg.get('models') or list(reg.MODELS):
        try:
            r = reg.fit_model('All', name, x[tr], y[tr])
            if r.spec.positive_x and np.any(x <= 0):
                raise ValueError('동일한 행에서 비교하기 위해 X>0 조건을 만족하지 않는 모델 제외')
            vm = metrics(y[va], r.predict(x[va]))
            fitted.append((vm['RMSE'], r, vm))
        except Exception as exc:
            failures.append(dict(model=name, reason=str(exc)[:200]))
    if not fitted:
        raise ValueError('동일 조건에서 비교 가능한 회귀모델이 없습니다.')
    _, best, vm = min(fitted, key=lambda row: row[0])
    rows = [dict(Model='ANN', **ann['metrics']), dict(Model=best.model, **metrics(y[te], best.predict(x[te])))]
    r = dict(kind='comparison', title='동일 데이터 분할 · 회귀 vs ANN', config=ann['config'], summary=rows,
             ann_result=ann['id'], regression_equation=best.equation, regression_validation=vm,
             regression_candidates=[dict(Model=b.model, **m) for _, b, m in fitted], split=ann['split'], failures=failures,
             evidence=dict(selection='회귀 후보는 Train에만 적합, Validation RMSE로 선택',
                           evaluation='ANN과 회귀가 동일한 Test 행에서 평가됨. 반복 비교로 Test에 맞추지 말 것',
                           features='동일한 1개 입력 변수', ann='선택한 고정 신경망 구조로 학습'))
    return save_result(owner, r, did)


def export(owner, rid):
    r = load_result(owner, rid)
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine='openpyxl') as writer:
        # Treat user-provided strings as literal cells, never Excel formulas.
        def sheet(name, rows):
            frame = pd.DataFrame(rows)
            for col in frame:
                frame[col] = frame[col].map(lambda v: "'" + v if isinstance(v, str) and v.startswith(('=', '+', '-', '@')) else v)
            frame.to_excel(writer, sheet_name=name, index=False)
        sheet('설정', [dict(key=k, value=json.dumps(v, ensure_ascii=False)) for k, v in r['config'].items()])
        sheet('구현근거', [dict(key=k, value=str(v)) for k, v in r['evidence'].items()])
        _, original_frame = dataset(owner,r['dataset'])
        sheet('입력데이터',original_frame.to_dict('records'))
        if r.get('execution'):
            sheet('도구실행', [dict(key=k, value=json.dumps(v, ensure_ascii=False)) for k, v in r['execution'].items()])
        if 'summary' in r:
            sheet('모델비교', r['summary'])
        if 'metrics' in r:
            sheet('Test지표', [r['metrics']])
            sheet('학습곡선', [dict(epoch=i+1, **{k: v[i] for k, v in r['history'].items()}) for i in range(r['actual_epochs'])])
            sheet('표준화', [dict(feature=f, mean=r['scaler']['x_mean'][i], scale=r['scaler']['x_scale'][i]) for i, f in enumerate(r['config']['features'])])
            for i, arr in enumerate(r['weights']):
                sheet(f'WeightBias{i+1}', np.atleast_2d(arr).tolist())
        for key in ('parameters', 'predictions', 'residuals', 'failures'):
            if r.get(key):
                sheet(key, r[key])
    return out.getvalue()
