# Extracted from Regression-Analysis-Tool; see SOURCES.json.
from __future__ import annotations
import io
import math
from dataclasses import dataclass
from typing import Callable
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.stats import t as student_t
APP_TITLE = '선형·비선형 회귀 분석 프로그램'
NONE = '(None)'

def _safe_name(value: object, index: int) -> str:
    if pd.isna(value) or not str(value).strip() or str(value).lower().startswith('unnamed'):
        letters = ''
        number = index + 1
        while number:
            (number, remainder) = divmod(number - 1, 26)
            letters = chr(65 + remainder) + letters
        return f'Column_{letters}'
    return str(value).strip()

def make_unique(values: list[object]) -> list[str]:
    counts: dict[str, int] = {}
    result: list[str] = []
    for (index, value) in enumerate(values):
        base = _safe_name(value, index)
        counts[base] = counts.get(base, 0) + 1
        result.append(base if counts[base] == 1 else f'{base}_{counts[base]}')
    return result

def _is_number(value: object) -> bool:
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False

def guess_header_row(raw: pd.DataFrame, max_rows: int=20) -> int:
    (best_row, best_score) = (0, -1.0)
    for row_i in range(min(max_rows, len(raw))):
        row = raw.iloc[row_i]
        present = row.dropna()
        if present.empty:
            continue
        text_count = sum((not _is_number(value) for value in present))
        unique_count = present.astype(str).nunique()
        score = len(present) + 2.0 * text_count + 0.2 * unique_count
        if score > best_score:
            (best_row, best_score) = (row_i, score)
    return best_row

def r2_score(y: np.ndarray, predicted: np.ndarray) -> float:
    sse = float(np.sum((y - predicted) ** 2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    return float('nan') if sst <= np.finfo(float).eps else 1.0 - sse / sst

def linear(x, a, b):
    return a * x + b

def quadratic(x, a, b, c):
    return a * x ** 2 + b * x + c

def cubic(x, a, b, c, d):
    return a * x ** 3 + b * x ** 2 + c * x + d

def exponential(x, a, b, c):
    with np.errstate(over='ignore', invalid='ignore'):
        return a * np.exp(np.clip(b * x, -700, 700)) + c

def logarithmic(x, a, b):
    with np.errstate(divide='ignore', invalid='ignore'):
        return a * np.log(x) + b

def power(x, a, b):
    with np.errstate(over='ignore', invalid='ignore'):
        return a * np.power(x, b)

def logistic4(x, lower, upper, midpoint, slope):
    with np.errstate(over='ignore', invalid='ignore'):
        return lower + (upper - lower) / (1.0 + np.exp(np.clip(-slope * (x - midpoint), -700, 700)))

@dataclass(frozen=True)
class ModelSpec:
    name: str
    function: Callable
    parameters: tuple[str, ...]
    minimum_points: int
    positive_x: bool = False
MODELS: dict[str, ModelSpec] = {'Linear': ModelSpec('Linear', linear, ('a', 'b'), 2), 'Quadratic': ModelSpec('Quadratic', quadratic, ('a', 'b', 'c'), 3), 'Cubic': ModelSpec('Cubic', cubic, ('a', 'b', 'c', 'd'), 4), 'Exponential': ModelSpec('Exponential', exponential, ('a', 'b', 'c'), 3), 'Logarithmic': ModelSpec('Logarithmic', logarithmic, ('a', 'b'), 2, True), 'Power': ModelSpec('Power', power, ('a', 'b'), 2, True), 'Logistic 4P': ModelSpec('Logistic 4P', logistic4, ('lower', 'upper', 'midpoint', 'slope'), 4)}

@dataclass
class FitResult:
    case: str
    model: str
    spec: ModelSpec
    params: np.ndarray
    covariance: np.ndarray
    standard_errors: np.ndarray
    x: np.ndarray
    y: np.ndarray
    y_hat: np.ndarray
    residuals: np.ndarray
    n: int
    k: int
    r2: float
    adjusted_r2: float
    rmse: float
    mae: float
    sse: float
    aic: float
    aicc: float
    bic: float
    equation: str
    outlier_mask: np.ndarray

    def predict(self, values: np.ndarray) -> np.ndarray:
        return np.asarray(self.spec.function(values, *self.params), dtype=float)

def initial_guess(name: str, x: np.ndarray, y: np.ndarray):
    span_x = max(float(np.ptp(x)), 1e-09)
    span_y = max(float(np.ptp(y)), 1e-09)
    if name == 'Exponential':
        guess = np.array([span_y, 1.0 / span_x, float(np.min(y))])
        bounds = (np.array([-np.inf, -100.0 / span_x, -np.inf]), np.array([np.inf, 100.0 / span_x, np.inf]))
    elif name == 'Logistic 4P':
        corr = np.corrcoef(x, y)[0, 1]
        direction = 1.0 if np.isfinite(corr) and corr >= 0 else -1.0
        guess = np.array([float(np.min(y)), float(np.max(y)), float(np.median(x)), direction / span_x])
        bounds = (np.array([-np.inf, -np.inf, float(np.min(x)) - span_x, -100.0 / span_x]), np.array([np.inf, np.inf, float(np.max(x)) + span_x, 100.0 / span_x]))
    elif name == 'Power':
        (lx, ly) = (np.log(x), np.log(np.clip(np.abs(y), 1e-12, None)))
        (slope, intercept) = np.polyfit(lx, ly, 1)
        guess = np.array([float(np.exp(intercept)) * (1 if np.mean(y) >= 0 else -1), float(slope)])
        bounds = (np.array([-np.inf, -100.0]), np.array([np.inf, 100.0]))
    else:
        guess = np.ones(len(MODELS[name].parameters))
        bounds = (np.full(len(guess), -np.inf), np.full(len(guess), np.inf))
    return (guess, bounds)

def equation_text(model: str, p: np.ndarray) -> str:
    f = lambda v: f'{v:.6g}'
    if model == 'Linear':
        return f'y = {f(p[0])}x + {f(p[1])}'
    if model == 'Quadratic':
        return f'y = {f(p[0])}x² + {f(p[1])}x + {f(p[2])}'
    if model == 'Cubic':
        return f'y = {f(p[0])}x³ + {f(p[1])}x² + {f(p[2])}x + {f(p[3])}'
    if model == 'Exponential':
        return f'y = {f(p[0])} exp({f(p[1])}x) + {f(p[2])}'
    if model == 'Logarithmic':
        return f'y = {f(p[0])} ln(x) + {f(p[1])}'
    if model == 'Power':
        return f'y = {f(p[0])} x^{f(p[1])}'
    return f'y = {f(p[0])} + ({f(p[1])} - {f(p[0])}) / (1 + exp(-{f(p[3])}(x - {f(p[2])})))'

def fit_model(case: str, model_name: str, x: np.ndarray, y: np.ndarray) -> FitResult:
    spec = MODELS[model_name]
    mask = np.isfinite(x) & np.isfinite(y)
    if spec.positive_x:
        mask &= x > 0
    (x, y) = (x[mask], y[mask])
    (n, k) = (len(x), len(spec.parameters))
    if n <= k or n < spec.minimum_points:
        raise ValueError(f'{model_name}: at least {k + 1} valid points are required')
    if np.unique(x).size < spec.minimum_points:
        raise ValueError(f'{model_name}: not enough unique X values')
    if model_name in ('Linear', 'Quadratic', 'Cubic'):
        degree = {'Linear': 1, 'Quadratic': 2, 'Cubic': 3}[model_name]
        (params, covariance) = np.polyfit(x, y, degree, cov=True)
    else:
        (guess, bounds) = initial_guess(model_name, x, y)
        (params, covariance) = curve_fit(spec.function, x, y, p0=guess, bounds=bounds, maxfev=100000, method='trf')
    y_hat = np.asarray(spec.function(x, *params), dtype=float)
    if not np.all(np.isfinite(y_hat)):
        raise ValueError(f'{model_name}: fitted values are not finite')
    residuals = y - y_hat
    sse = float(np.sum(residuals ** 2))
    mse = sse / n
    r2 = r2_score(y, y_hat)
    adjusted = float('nan') if n <= k else 1.0 - (1.0 - r2) * (n - 1) / (n - k)
    rmse = math.sqrt(mse)
    mae = float(np.mean(np.abs(residuals)))
    safe_mse = max(mse, np.finfo(float).tiny)
    aic = n * math.log(safe_mse) + 2 * k
    aicc = float('inf') if n <= k + 1 else aic + 2 * k * (k + 1) / (n - k - 1)
    bic = n * math.log(safe_mse) + k * math.log(n)
    standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    residual_sd = math.sqrt(sse / max(n - k, 1))
    standardized = residuals / max(residual_sd, np.finfo(float).eps)
    outliers = np.abs(standardized) >= 2.0
    return FitResult(case=case, model=model_name, spec=spec, params=params, covariance=covariance, standard_errors=standard_errors, x=x, y=y, y_hat=y_hat, residuals=residuals, n=n, k=k, r2=r2, adjusted_r2=adjusted, rmse=rmse, mae=mae, sse=sse, aic=aic, aicc=aicc, bic=bic, equation=equation_text(model_name, params), outlier_mask=outliers)

def confidence_band(result: FitResult, x_grid: np.ndarray, level: float=0.95):
    predicted = result.predict(x_grid)
    p = result.params
    jacobian = np.empty((len(x_grid), len(p)), dtype=float)
    for index in range(len(p)):
        step = math.sqrt(np.finfo(float).eps) * max(abs(float(p[index])), 1.0)
        (upper_p, lower_p) = (p.copy(), p.copy())
        upper_p[index] += step
        lower_p[index] -= step
        jacobian[:, index] = (result.spec.function(x_grid, *upper_p) - result.spec.function(x_grid, *lower_p)) / (2.0 * step)
    variances = np.einsum('ij,jk,ik->i', jacobian, result.covariance, jacobian)
    se = np.sqrt(np.maximum(variances, 0.0))
    critical = student_t.ppf((1.0 + level) / 2.0, max(result.n - result.k, 1))
    return (predicted - critical * se, predicted + critical * se)

def read_uploaded_raw(uploaded_file, sheet_name: str | None=None) -> tuple[pd.DataFrame, list[str]]:
    suffix = uploaded_file.name.lower().rsplit('.', 1)[-1]
    data = uploaded_file.getvalue()
    if suffix == 'csv':
        try:
            raw = pd.read_csv(io.BytesIO(data), header=None, encoding='utf-8-sig')
        except UnicodeDecodeError:
            raw = pd.read_csv(io.BytesIO(data), header=None, encoding='cp949')
        return (raw.dropna(axis=1, how='all'), [])
    excel = pd.ExcelFile(io.BytesIO(data))
    sheets = excel.sheet_names
    selected = sheet_name or sheets[0]
    raw = pd.read_excel(io.BytesIO(data), sheet_name=selected, header=None)
    return (raw.dropna(axis=1, how='all'), sheets)

def apply_header(raw: pd.DataFrame, header_row_1based: int) -> pd.DataFrame:
    row = header_row_1based - 1
    if row < 0 or row >= len(raw):
        raise ValueError(f'Header row must be between 1 and {len(raw)}')
    columns = make_unique(raw.iloc[row].tolist())
    data = raw.iloc[row + 1:].copy()
    data.columns = columns
    return data.dropna(how='all').reset_index(drop=True)

def analysis_groups(data: pd.DataFrame, group_col: str):
    if group_col == NONE:
        return [('All', data)]
    return [(str(name), frame.copy()) for (name, frame) in data.groupby(group_col, dropna=False, sort=False)]

def best_results(results: list[FitResult]) -> dict[str, FitResult]:
    best: dict[str, FitResult] = {}
    for result in results:
        score = result.aicc if np.isfinite(result.aicc) else result.aic
        current = best.get(result.case)
        current_score = current.aicc if current and np.isfinite(current.aicc) else current.aic if current else float('inf')
        if score < current_score:
            best[result.case] = result
    return best

def build_summary_df(results: list[FitResult]) -> pd.DataFrame:
    best = best_results(results)
    rows = []
    for r in results:
        rows.append({'Best': '★' if best.get(r.case) is r else '', 'Case': r.case, 'Model': r.model, 'N': r.n, 'R²': r.r2, 'Adjusted R²': r.adjusted_r2, 'RMSE': r.rmse, 'MAE': r.mae, 'SSE': r.sse, 'AIC': r.aic, 'AICc': r.aicc, 'BIC': r.bic, 'Equation': r.equation})
    df = pd.DataFrame(rows)
    return df.sort_values(['Case', 'Best', 'AICc'], ascending=[True, False, True]).reset_index(drop=True)

def build_parameter_df(results: list[FitResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        for (name, value, se) in zip(r.spec.parameters, r.params, r.standard_errors):
            rows.append({'Case': r.case, 'Model': r.model, 'Parameter': name, 'Estimate': value, 'Standard Error': se})
    return pd.DataFrame(rows)

def build_predictions_df(results: list[FitResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        residual_sd = math.sqrt(r.sse / max(r.n - r.k, 1))
        standardized = r.residuals / max(residual_sd, np.finfo(float).eps)
        for (i, (xv, yv, pred, resid, stdres, outlier)) in enumerate(zip(r.x, r.y, r.y_hat, r.residuals, standardized, r.outlier_mask), start=1):
            rows.append({'Case': r.case, 'Model': r.model, 'Index': i, 'X': xv, 'Observed Y': yv, 'Predicted Y': pred, 'Residual': resid, 'Standardized Residual': stdres, 'Outlier': bool(outlier)})
    return pd.DataFrame(rows)

def build_best_residual_df(results: list[FitResult]) -> pd.DataFrame:
    best = best_results(results)
    pred = build_predictions_df(results)
    if pred.empty:
        return pred
    mask = pred.apply(lambda row: best.get(row['Case']) is not None and best[row['Case']].model == row['Model'], axis=1)
    return pred[mask].reset_index(drop=True)

def export_excel_bytes(results: list[FitResult], failures: list[dict], data: pd.DataFrame) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        build_summary_df(results).to_excel(writer, sheet_name='Model Summary', index=False)
        build_parameter_df(results).to_excel(writer, sheet_name='Parameters', index=False)
        build_predictions_df(results).to_excel(writer, sheet_name='All Predictions', index=False)
        build_best_residual_df(results).to_excel(writer, sheet_name='Best Residuals', index=False)
        build_algorithm_df().to_excel(writer, sheet_name='Algorithm', index=False)
        if failures:
            pd.DataFrame(failures).to_excel(writer, sheet_name='Failed Models', index=False)
        data.to_excel(writer, sheet_name='Input Data', index=False)
        for sheet in writer.book.worksheets:
            sheet.freeze_panes = 'A2'
            sheet.auto_filter.ref = sheet.dimensions
            for cells in sheet.columns:
                width = min(max((len(str(c.value)) if c.value is not None else 0 for c in cells)) + 2, 55)
                sheet.column_dimensions[cells[0].column_letter].width = width
    return output.getvalue()

def run_models(data, x_col, y_col, group_col, selected_models):
    results: list[FitResult] = []
    failures: list[dict] = []
    for (case, frame) in analysis_groups(data, group_col):
        x_all = pd.to_numeric(frame[x_col], errors='coerce').to_numpy(dtype=float)
        y_all = pd.to_numeric(frame[y_col], errors='coerce').to_numpy(dtype=float)
        for name in selected_models:
            try:
                results.append(fit_model(case, name, x_all, y_all))
            except Exception as exc:
                failures.append({'Case': case, 'Model': name, 'Reason': str(exc)})
    return (results, failures)

def build_algorithm_df() -> pd.DataFrame:
    """\uacfc\uc81c \uc124\uba85\uc6a9: \ud504\ub85c\uadf8\ub7a8 \ub0b4\ubd80\uc5d0\uc11c \uc2e4\uc81c \uc0ac\uc6a9\ud558\ub294 \ucc98\ub9ac \uc54c\uace0\ub9ac\uc998 \uc694\uc57d."""
    return pd.DataFrame([{'단계': '1. 데이터 전처리', '알고리즘': 'CSV/Excel 읽기 → Header 적용 → X/Y 숫자 변환 → 결측/비수치 제거', '구현': 'Pandas'}, {'단계': '2. 선형·다항 회귀', '알고리즘': '잔차제곱합(SSE)이 최소가 되도록 회귀계수 계산', '구현': 'NumPy polyfit (최소제곱 적합)'}, {'단계': '3. 비선형 회귀', '알고리즘': '초기 파라미터에서 시작해 잔차제곱합이 감소하도록 반복 최적화', '구현': 'SciPy curve_fit + Trust Region Reflective(TRF)'}, {'단계': '4. 모델 평가', '알고리즘': '예측값과 관측값의 잔차로 R², RMSE, MAE, SSE, AIC/AICc/BIC 계산', '구현': 'NumPy / Python'}, {'단계': '5. 최적 모델 선택', '알고리즘': '계산 가능한 모델 중 AICc 최소 모델 선택, AICc 불가 시 AIC 최소 모델 선택', '구현': 'best_results()'}, {'단계': '6. 이상치 후보', '알고리즘': '표준화 잔차의 절댓값이 2 이상인 점을 후보로 표시', '구현': '|standardized residual| ≥ 2'}, {'단계': '7. 신뢰구간·예측', '알고리즘': '파라미터 공분산과 t 분포로 95% 신뢰구간 근사, 최적 회귀식으로 새 X의 Y 예측', '구현': 'Jacobian + covariance + Student t'}])
