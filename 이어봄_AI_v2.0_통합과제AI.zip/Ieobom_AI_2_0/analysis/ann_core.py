"""Original ANN architecture extracted from the submitted program."""
import tensorflow as tf

def build_model(input_dim: int, hidden_units: int, activation_name: str, learning_rate: float, l2_value: float) -> tf.keras.Model:
    model = tf.keras.Sequential(name='ANN_Regressor')
    model.add(tf.keras.Input(shape=(input_dim,), name='Input_Layer'))
    model.add(tf.keras.layers.Dense(units=hidden_units, activation=None, use_bias=True, kernel_regularizer=tf.keras.regularizers.l2(l2_value) if l2_value > 0 else None, name='Dense_Hidden_Layer'))
    model.add(tf.keras.layers.Activation(activation_name, name='Activation_Function'))
    model.add(tf.keras.layers.Dense(units=1, activation='linear', name='Dense_Output_Layer'))
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate), loss='mse', metrics=['mae'])
    return model
