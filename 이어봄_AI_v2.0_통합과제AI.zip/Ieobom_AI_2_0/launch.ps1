param([switch]$NoBrowser, [switch]$InstallModel)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$runtimeReference = Join-Path $PSScriptRoot 'PYTHON_PATH.txt'
$pythonExecutable = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (Test-Path -LiteralPath $runtimeReference) {
    $pythonExecutable = [IO.File]::ReadAllText($runtimeReference).Trim()
}
if (-not (Test-Path -LiteralPath $pythonExecutable -PathType Leaf)) {
    Write-Host 'Run INSTALL.cmd first.'
    exit 1
}
$env:PYTHONUTF8 = '1'
if ($InstallModel) {
    & $pythonExecutable (Join-Path $PSScriptRoot 'install_model.py')
} elseif ($NoBrowser) {
    & $pythonExecutable -u (Join-Path $PSScriptRoot 'start.py') --no-browser
} else {
    & $pythonExecutable -u (Join-Path $PSScriptRoot 'start.py')
}
exit $LASTEXITCODE
