"""Download the official portable Ollama distribution and the selected local model."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from start import get, load_config, ollama_executable

ROOT=Path(__file__).resolve().parent
runtime=ROOT/'runtime/ollama'


def main():
    config=load_config()
    model=config.get('model','qwen3.5:9b')
    endpoint=config.get('ollama_url','') or next((u for u in ['http://127.0.0.1:11435','http://127.0.0.1:11434'] if get(u+'/api/tags')), '')
    if endpoint:
        tags=get(endpoint+'/api/tags') or {}
        if model not in [row['name'] for row in tags.get('models',[])]:
            print('Downloading '+model+' through the existing local Ollama server...',flush=True)
            req=urllib.request.Request(endpoint+'/api/pull', data=json.dumps(dict(name=model,stream=True)).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=3600) as response:
                last=''
                for line in response:
                    row=json.loads(line)
                    if row.get('error'):
                        raise RuntimeError(row['error'])
                    if row.get('status') != last:
                        last=row.get('status','')
                        print(last,flush=True)
        config.update(model=model,ollama_url=endpoint)
        (ROOT/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
        print('Existing local model ready. Run START.cmd.',flush=True)
        return
    runtime.mkdir(parents=True,exist_ok=True)
    executable=ollama_executable()
    if not executable:
        req=urllib.request.Request('https://api.github.com/repos/ollama/ollama/releases/latest',headers={'User-Agent':'Ieobom-Analysis-Setup'})
        with urllib.request.urlopen(req,timeout=30) as response:
            release=json.load(response)
        asset=next(a for a in release['assets'] if a['name']=='ollama-windows-amd64.zip')
        print('Downloading official Ollama '+release['tag_name']+' ('+str(round(asset['size']/1024**3,2))+' GB)...',flush=True)
        archive=runtime/'ollama.zip'
        def report(block,size,total):
            if total>0 and block%1000==0:
                print(str(min(100,int(block*size*100/total)))+'%',flush=True)
        urllib.request.urlretrieve(asset['browser_download_url'],archive,reporthook=report)
        with zipfile.ZipFile(archive) as source:
            for info in source.infolist():
                target=(runtime/info.filename).resolve()
                if not target.is_relative_to(runtime.resolve()):
                    raise ValueError('Invalid archive path')
            source.extractall(runtime)
        # The archive is retained so setup does not need to download it again.
        executable=str(runtime/'ollama.exe')
    child=None
    env=os.environ.copy()
    env['OLLAMA_NO_CLOUD']='true'
    try:
        if not endpoint:
            endpoint='http://127.0.0.1:11435'
            env.update(OLLAMA_HOST='127.0.0.1:11435',OLLAMA_MODELS=str(ROOT/'models'))
            child=subprocess.Popen([executable,'serve'],env=env,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            for _ in range(60):
                if get(endpoint+'/api/tags'):
                    break
                time.sleep(1)
            else:
                raise RuntimeError('Ollama did not start')
        env['OLLAMA_HOST']=endpoint
        print('Model: '+model+' · first download may take several minutes.',flush=True)
        subprocess.run([executable,'pull',model],env=env,check=True)
        config.update(model=model,ollama_url=endpoint)
        (ROOT/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
        print('Model ready. Run START.cmd.',flush=True)
    finally:
        if child:
            child.terminate()
            child.wait(timeout=15)


if __name__=='__main__':
    main()
